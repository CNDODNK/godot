class_name VysheLocalization
extends Node
var language: String = "ru"
var strings: Dictionary = {"menu_title":"ВЫШЕ", "hook_free":"СВОБОДЕН", "hook_attached":"ЗАЦЕПЛЕН", "pause":"ПАУЗА", "fail":"СРЫВ!"}
func tr_key(key: String) -> String: return str(strings.get(key, key))
