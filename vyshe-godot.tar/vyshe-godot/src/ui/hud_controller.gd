class_name VysheHudController
extends CanvasLayer

func update_hud(height: float, stamina: float, left: bool, right: bool, zone: String, muted: bool) -> void:
	$Height.text = "СТРАТУМ %d м  |  %s" % [roundi(height), zone]
	$Stamina.value = stamina
	$Hook.text = "К1 %s  |  К2 %s" % [_hook_status(left), _hook_status(right)]
	$Hint.text = "ESC — ПАУЗА   M — %s" % ("ЗВУК ВЫКЛ" if muted else "ЗВУК ВКЛ")

func _hook_status(attached: bool) -> String:
	return "ЗАЦЕПЛЕН" if attached else "СВОБОДЕН"
