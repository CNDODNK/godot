class_name VysheMenuController
extends Control

signal requested(action: StringName)
@onready var continue_button: Button = %Continue

func _ready() -> void:
	var actions: Node = $Panel/Actions
	for child: Node in actions.get_children():
		var button: Button = child as Button
		if button:
			button.pressed.connect(requested.emit.bind(button.name))

func activate(can_continue: bool) -> void:
	continue_button.disabled = not can_continue
	show()
	$Panel/Actions/NewGame.grab_focus()
