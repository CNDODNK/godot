class_name VysheUiFlowController
extends Control
const EventBusService = preload("res://autoload/event_bus.gd")
@export var menu: Control
@export var pause: Control
@export var failure: Control
@export var safe_boot: Control
func _ready() -> void:
	GameState.game_state_changed.connect(_on_state_changed)
	_on_state_changed(GameState.State.BOOT, GameState.current)
func _on_state_changed(_previous: int, next_state: int) -> void:
	menu.visible = next_state == GameState.State.MENU or next_state == GameState.State.CATALOG
	pause.visible = next_state == GameState.State.PAUSED
	failure.visible = next_state == GameState.State.FAILED
