class_name VysheSettingsScreen
extends Control
func set_option(key: String, value: Variant) -> void:
	Settings.apply_patch({key: value}); Settings.save_settings()
