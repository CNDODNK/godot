class_name VysheMainMenuFlow
extends Control

const GameScene: PackedScene = preload("res://scenes/game/game.tscn")
const SettingsScene: PackedScene = preload("res://scenes/ui/settings.tscn")
@onready var menu: VysheMenuController = $Menu
@onready var status: Label = $Menu/Panel/Status
var settings: VysheSettingsController

func _ready() -> void:
	menu.requested.connect(_on_menu_action)
	menu.activate(false)
	settings = SettingsScene.instantiate() as VysheSettingsController
	settings.hide()
	add_child(settings)
	settings.crt_changed.connect(_on_crt_changed)
	settings.closed.connect(_close_settings)

func _on_menu_action(action: StringName) -> void:
	match action:
		&"NewGame":
			status.text = "ЗАГРУЗКА"
			var game: Node = GameScene.instantiate()
			get_tree().root.add_child(game)
			queue_free()
		&"Continue":
			status.text = "ПРОДОЛЖЕНИЕ"
		&"Settings":
			menu.hide()
			settings.activate(true)
		&"Memory":
			status.text = "MEMORY CARD"
		&"Quit":
			get_tree().quit()

func _close_settings() -> void:
	settings.hide()
	menu.show()
	menu.activate(false)

func _on_crt_changed(enabled: bool) -> void:
	var service: Node = load("res://autoload/settings.gd").new()
	service.apply_patch({"crt": enabled})
	service.save_settings()
