class_name VysheMemoryCardScreen
extends Control

signal closed()

func _ready() -> void:
	$Panel/Back.pressed.connect(closed.emit)

func activate(save: Dictionary) -> void:
	%Slot.text = "SLOT 1  ПУСТОЙ" if save.is_empty() else "SLOT 1  ТОЧКА %d" % (int(save.get("index", 0)) + 1)
	show()
	$Panel/Back.grab_focus()
