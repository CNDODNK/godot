class_name VyshePauseController
extends Control

signal requested(action: StringName)

func _ready() -> void:
	for child: Node in $Panel.get_children():
		var button: Button = child as Button
		if button:
			button.pressed.connect(requested.emit.bind(button.name))

func activate(title: String, resume_text: String) -> void:
	$Panel/Title.text = title
	$Panel/Resume.text = resume_text
	show()
	$Panel/Resume.grab_focus()
