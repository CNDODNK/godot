class_name VysheSafeBootScreen
extends Control
@onready var reason: Label = %Reason
func show_error(message: String) -> void:
	reason.text = message
	show()
func _on_restart_pressed() -> void:
	var settings: Node = load("res://autoload/settings.gd").new()
	settings.apply_patch({"crt": false, "resolution": 320, "shadows": false, "particles": false})
	get_tree().reload_current_scene()
