class_name VysheSettingsController
extends Control

signal crt_changed(enabled: bool)
signal closed()

func _ready() -> void:
	$Panel/CRT.toggled.connect(crt_changed.emit)
	$Panel/Back.pressed.connect(closed.emit)

func activate(crt_enabled: bool) -> void:
	$Panel/CRT.set_pressed_no_signal(crt_enabled)
	show()
	$Panel/CRT.grab_focus()
