class_name VysheGameController
extends Node3D

const PlayerScene: PackedScene = preload("res://scenes/player/player.tscn")
const Card = preload("res://autoload/memory_card.gd")
const Failure = preload("res://src/world/failure_controller.gd")
const State = preload("res://autoload/game_state.gd")
const Audio = preload("res://src/core/procedural_audio.gd")
const Backdrop = preload("res://src/core/backdrop.gd")
@onready var world: VysheWorldRuntime = $World
@onready var spawn: Marker3D = $Spawn
var player: VyshePlayerController
var checkpoint_height: float = -299.0
var checkpoint_index: int = 0
var failure: Node
var save_card: Node
var elapsed: float = 0.0
var audio: Node
var last_grounded: bool = false
var backdrop: Node
@onready var ps1_overlay: ColorRect = $PS1Overlay/Pass
var ps1_enabled: bool = true
var ps1_jitter: bool = true

func _ready() -> void:
	save_card = Card.new()
	failure = Failure.new()
	add_child(failure)
	var saved: Dictionary = save_card.load_slot(0)
	checkpoint_height = float(saved.get("height", -299.0)) if not saved.is_empty() else -299.0
	checkpoint_index = int(saved.get("index", 0)) if not saved.is_empty() else 0
	world.start(int(saved.get("seed", 7771777)) if not saved.is_empty() else 7771777)
	audio = Audio.new()
	add_child(audio)
	backdrop = Backdrop.new()
	add_child(backdrop)
	_spawn_player()
	audio.trigger("checkpoint", 0.35)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	_apply_ps1()
	_update_hud()

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_C:
			ps1_enabled = not ps1_enabled
			_apply_ps1()
		elif event.keycode == KEY_V:
			ps1_jitter = not ps1_jitter
			_apply_ps1()

func _apply_ps1() -> void:
	if ps1_overlay == null: return
	ps1_overlay.visible = ps1_enabled
	ps1_overlay.material.set_shader_parameter("crt_strength", 0.75 if ps1_enabled else 0.0)
	ps1_overlay.material.set_shader_parameter("jitter_strength", 0.25 if ps1_jitter else 0.0)

func _spawn_player() -> void:
	if is_instance_valid(player): player.queue_free()
	player = PlayerScene.instantiate() as VyshePlayerController
	add_child(player)
	player.global_position = Vector3(0.0, checkpoint_height + 1.0, 2.0)

func _process(delta: float) -> void:
	if player == null: return
	elapsed += delta
	world.set_active_height(player.global_position.y)
	if backdrop != null:
		backdrop.set_player_position(player.global_position)
		backdrop.set_height(player.global_position.y - 0.85)
	var active: Dictionary = world.sections[world.active_index] if not world.sections.is_empty() else {}
	if not active.is_empty() and float(active.get("exit", checkpoint_height)) > checkpoint_height:
		checkpoint_height = float(active["exit"])
		checkpoint_index = int(active["index"])
		failure.set_checkpoint(_checkpoint_for(active))
		if int(active["index"]) % 2 == 0 and int(active["index"]) > 0:
			save_card.save_slot(0, {"seed": world.run_seed, "index": checkpoint_index, "height": checkpoint_height})
			audio.trigger("checkpoint", 0.8)
	if player.global_position.y < checkpoint_height - 12.0:
		audio.trigger("fail", 1.0)
		_respawn()
	_update_hud()

func _respawn() -> void:
	_spawn_player()
	world.set_active_height(checkpoint_height)
	_update_hud()

func _checkpoint_for(data: Dictionary) -> VysheCheckpoint:
	var value: VysheCheckpoint = VysheCheckpoint.new()
	value.checkpoint_id = int(data.get("index", 0))
	value.height_meters = float(data.get("exit", -299.0))
	value.world_seed = world.run_seed
	value.section_index = value.checkpoint_id
	return value

func _update_hud() -> void:
	var zone: Dictionary = VysheStrataGenerator.zone_at(player.global_position.y - 0.85)
	$HUD.update_hud(player.global_position.y - 0.85, player.stamina.value, player.grapples.left.is_attached, player.grapples.right.is_attached, str(zone.get("name", "ДНИЩЕ")), false)
