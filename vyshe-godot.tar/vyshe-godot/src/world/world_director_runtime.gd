class_name VysheWorldRuntime
extends Node3D

const SectionRuntime = preload("res://src/world/section_runtime.gd")
signal section_loaded(section: Dictionary)
signal section_unloaded(index: int)
@export var section_scene: PackedScene
@export var stream_ahead: int = 3
@export var stream_behind: int = 2
var sections: Array[Dictionary] = []
var loaded: Dictionary = {}
var active_index: int = 0
var run_seed: int = 0

func start(seed_value: int) -> bool:
	run_seed = seed_value
	sections = VysheStrataGenerator.build(seed_value, 32)
	var errors: Array[String] = VysheLevelValidator.validate(sections)
	if not errors.is_empty(): push_error("Level validation failed: " + ", ".join(errors)); return false
	active_index = 0
	_update_stream()
	return true

func set_active_height(height: float) -> void:
	for index: int in range(sections.size()):
		var data: Dictionary = sections[index]
		if height >= float(data.origin) and height < float(data.exit): active_index = index; break
	_update_stream()

func _update_stream() -> void:
	var first: int = maxi(0, active_index - stream_behind)
	var last: int = mini(sections.size() - 1, active_index + stream_ahead)
	for index: int in range(first, last + 1):
		if not loaded.has(index): _load_section(index)
	for key: int in loaded.keys():
		if key < first or key > last: _unload_section(key)

func _load_section(index: int) -> void:
	var node: Node3D = (section_scene.instantiate() if section_scene else SectionRuntime.new()) as Node3D
	add_child(node)
	(node as SectionRuntime).build(sections[index])
	loaded[index] = node
	section_loaded.emit(sections[index])

func _unload_section(index: int) -> void:
	var node: Node = loaded[index]
	if is_instance_valid(node): node.queue_free()
	loaded.erase(index)
	section_unloaded.emit(index)
