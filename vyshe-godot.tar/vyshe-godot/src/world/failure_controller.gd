class_name VysheFailureController
extends Node
const EventBusService = preload("res://autoload/event_bus.gd")
const State = preload("res://autoload/game_state.gd")
var event_bus: Node = EventBusService.new()
var game_state: Node = State.new()
@export var fall_threshold: float = 12.0
var last_checkpoint: VysheCheckpoint
func set_checkpoint(value: VysheCheckpoint) -> void: last_checkpoint = value
func check_fall(height: float, checkpoint_height: float) -> bool:
	if height >= checkpoint_height - fall_threshold: return false
	event_bus.player_fell.emit(height); game_state.current = State.State.FAILED; return true
