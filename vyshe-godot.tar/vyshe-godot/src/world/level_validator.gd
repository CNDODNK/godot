class_name VysheLevelValidator
extends RefCounted
static func validate(sections: Array[Dictionary]) -> Array[String]:
	var errors: Array[String] = []
	if sections.is_empty(): errors.append("Нет секций")
	for section: Dictionary in sections:
		if int(section.get("holds", 0)) < 2: errors.append("Мало зацепов в секции %d" % int(section["index"]))
		if float(section.get("exit", 0.0)) <= float(section.get("origin", 0.0)): errors.append("Выход не выше старта")
		if int(section.get("decor", 0)) > int(section.get("holds", 0)) * 3: errors.append("Декор может блокировать путь в секции %d" % int(section["index"]))
	return errors
