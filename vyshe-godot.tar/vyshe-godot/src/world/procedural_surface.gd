class_name VysheProceduralSurface
extends RefCounted

static func texture(seed_value: int, base: Color, accent: Color) -> ImageTexture:
	var image: Image = Image.create(64, 64, false, Image.FORMAT_RGB8)
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = seed_value
	for y: int in range(64):
		for x: int in range(64):
			var noise: float = rng.randf_range(-0.11, 0.11)
			var color: Color = base
			if ((x / 8) + (y / 8)) % 2 == 0: color = color.lerp(accent, 0.16)
			color = Color(clampf(color.r + noise, 0.0, 1.0), clampf(color.g + noise, 0.0, 1.0), clampf(color.b + noise, 0.0, 1.0))
			image.set_pixel(x, y, color)
	for index: int in range(14):
		var x: int = rng.randi_range(2, 61)
		var y: int = rng.randi_range(2, 61)
		for step: int in range(rng.randi_range(3, 10)):
			if x >= 0 and x < 64 and y >= 0 and y < 64: image.set_pixel(x, y, accent)
			x += rng.randi_range(-1, 1); y += rng.randi_range(-1, 1)
	return ImageTexture.create_from_image(image)

static func material(seed_value: int, base: Color, accent: Color, emission: bool = false) -> StandardMaterial3D:
	var material: StandardMaterial3D = StandardMaterial3D.new()
	material.albedo_texture = texture(seed_value, base, accent)
	material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	material.roughness = 0.82
	material.albedo_color = Color.WHITE
	if emission:
		material.emission_enabled = true
		material.emission = accent
		material.emission_energy_multiplier = 1.2
	return material
