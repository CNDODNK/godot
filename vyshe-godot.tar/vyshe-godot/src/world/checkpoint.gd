class_name VysheCheckpointNode
extends Area3D
@export var checkpoint: VysheCheckpoint
signal reached(data: VysheCheckpoint)
func _on_body_entered(body: Node3D) -> void:
	if body is VyshePlayerController and checkpoint != null:
		reached.emit(checkpoint); EventBus.checkpoint_reached.emit(checkpoint.checkpoint_id, checkpoint.height_meters)
