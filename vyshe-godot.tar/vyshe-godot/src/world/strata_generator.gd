class_name VysheStrataGenerator
extends RefCounted

const ZONES: Array[Dictionary] = [
	{"id":"bottom","name":"ДНИЩЕ","min":-300.0,"max":-200.0},
	{"id":"habitation","name":"ЗОНА ОБИТАНИЯ","min":-200.0,"max":-100.0},
	{"id":"approach","name":"ПОДСТУПЫ К ВОЗДУХУ","min":-100.0,"max":0.0},
	{"id":"surface","name":"ПОВЕРХНОСТЬ","min":0.0,"max":100.0},
	{"id":"clouds","name":"ОБЛАКА","min":100.0,"max":200.0},
	{"id":"strato","name":"СТРАТОСФЕРА","min":200.0,"max":300.0},
	{"id":"planets","name":"ПЛАНЕТЫ","min":300.0,"max":400.0},
	{"id":"stars","name":"ЗВЁЗДЫ","min":400.0,"max":500.0},
	{"id":"nebula","name":"ТУМАННОСТИ","min":500.0,"max":600.0},
	{"id":"galaxy","name":"ГАЛАКТИКИ","min":600.0,"max":INF}
]

static func zone_at(height: float) -> Dictionary:
	for zone: Dictionary in ZONES:
		if height < float(zone["max"]): return zone
	return ZONES.back()

static func build(seed_value: int, count: int = 12) -> Array[Dictionary]:
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = seed_value
	var sections: Array[Dictionary] = []
	var height: float = -300.0
	for index: int in range(count):
		var section_height: float = rng.randf_range(6.5, 8.5)
		var section_seed: int = rng.randi()
		var zone: Dictionary = zone_at(height)
		sections.append({
			"index": index,
			"seed": section_seed,
			"origin": height,
			"height": section_height,
			"exit": height + section_height,
			"holds": maxi(4, int(section_height * 1.4)),
			"decor": 6,
			"zone_id": str(zone.get("id", "bottom")),
			"archetype": "procedural_%s_%02d" % [str(zone.get("id", "bottom")), index],
			"generated": true
		})
		height += section_height
	return sections
