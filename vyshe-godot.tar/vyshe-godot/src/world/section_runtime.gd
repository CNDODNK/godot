class_name VysheSectionRuntime
extends Node3D

const Surface = preload("res://src/world/procedural_surface.gd")
var surface_texture: ImageTexture
var surface_material: StandardMaterial3D
var definition: Dictionary = {}
var checkpoint: VysheCheckpoint
var hatch: Area3D
var route_points: Array[Vector3] = []
var accent: Color = Color("#38e0ff")
var structure: Color = Color("#3f4656")
var catalog: Dictionary = {}
var light_count: int = 0
var scatter_count: int = 0

func build(data: Dictionary) -> void:
	definition = data
	position.y = float(data.get("origin", -300.0))
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = int(data.get("seed", 1))
	var zone: Dictionary = VysheStrataGenerator.zone_at(position.y)
	accent = _accent_for(str(zone.get("id", "bottom")))
	structure = _structure_for(str(zone.get("id", "bottom")))
	surface_texture = Surface.texture(int(data.get("seed", 1)), structure, accent)
	surface_material = Surface.material(int(data.get("seed", 1)), structure, accent)
	catalog = JSON.parse_string(FileAccess.get_file_as_string("res://data/archon_catalog.json"))
	_build_start_platform()
	_build_generated_architecture(rng, float(data.get("height", 7.0)))
	_build_route(rng, float(data.get("height", 7.0)))
	_build_columns(rng)
	_build_lighting(rng, float(data.get("height", 7.0)))
	_build_scatter(rng, float(data.get("height", 7.0)))
	_build_ceiling(float(data.get("height", 7.0)))
	_build_checkpoint(float(data.get("exit", -292.0)))

func _build_start_platform() -> void:
	_add_solid_box(Vector3(0.0, 0.0, 0.0), Vector3(7.0, 0.3, 7.0), structure)
	_add_trim(Vector3(0.0, 0.19, 3.35), Vector3(7.1, 0.06, 0.16))
	_add_trim(Vector3(0.0, 0.19, -3.35), Vector3(7.1, 0.06, 0.16))

func _build_generated_architecture(rng: RandomNumberGenerator, height: float) -> void:
	var zone_id: String = str(definition.get("zone_id", "bottom"))
	var recipes: Array = catalog.get(zone_id, catalog.get("ancient", []))
	if recipes.is_empty(): return
	var recipe: Array = recipes[int(definition.get("seed", 0)) % recipes.size()]
	for raw: Array in recipe[2]:
		var kind: String = str(raw[0])
		var point: Vector3 = Vector3(float(raw[1]), float(raw[2]), float(raw[3]))
		var size: Vector3 = Vector3(maxf(0.08, float(raw[4])), maxf(0.08, float(raw[5])), maxf(0.08, float(raw[6])))
		if point.y > height + 0.2: continue
		if kind == "cylinder":
			var mesh: CylinderMesh = CylinderMesh.new(); mesh.top_radius = size.x * 0.5; mesh.bottom_radius = size.x * 0.5; mesh.height = size.y; mesh.radial_segments = 8
			var node: MeshInstance3D = MeshInstance3D.new(); node.mesh = mesh; node.position = point; node.material_override = surface_material; add_child(node)
		else:
			_add_solid_box(point, size, structure) if bool(raw[11]) else _add_trim(point, size)

func _build_route(rng: RandomNumberGenerator, height: float) -> void:
	var steps: int = maxi(4, int(height / 1.35))
	for index: int in range(steps):
		var t: float = float(index + 1) / float(steps + 1)
		var point: Vector3 = Vector3(sin(float(index) * 1.7 + rng.randf()) * 2.0, t * height, cos(float(index) * 1.3 + rng.randf()) * 1.6)
		route_points.append(point)
		_add_solid_box(point, Vector3(1.8, 0.18, 1.5), structure.lightened(0.08))
		_add_hold(point + Vector3(0.0, 0.48, 0.72), Vector3(0.0, 0.0, 1.0), index % 3 == 0)
		_add_hold(point + Vector3(0.0, 0.55, -0.72), Vector3(0.0, 0.0, -1.0), index % 3 == 0)
		if index > 0:
			_add_rope(route_points[index - 1] + Vector3(0.0, 0.22, 0.0), point + Vector3(0.0, -0.22, 0.0))

func _build_columns(rng: RandomNumberGenerator) -> void:
	for index: int in range(6):
		var angle: float = float(index) * TAU / 6.0 + rng.randf_range(-0.18, 0.18)
		var radius: float = rng.randf_range(5.4, 7.0)
		var height: float = rng.randf_range(3.0, 6.0)
		var mesh: CylinderMesh = CylinderMesh.new()
		mesh.top_radius = 0.35
		mesh.bottom_radius = 0.55
		mesh.height = height
		mesh.radial_segments = 7
		var node: MeshInstance3D = MeshInstance3D.new()
		node.mesh = mesh
		node.position = Vector3(cos(angle) * radius, height * 0.5, sin(angle) * radius)
		node.material_override = _material(structure.darkened(0.12))
		add_child(node)

func _build_lighting(rng: RandomNumberGenerator, height: float) -> void:
	var lamp_count: int = 3 + int(rng.randf() * 3.0)
	for index: int in range(lamp_count):
		var lamp: OmniLight3D = OmniLight3D.new()
		lamp.position = Vector3(rng.randf_range(-3.0, 3.0), rng.randf_range(1.1, maxf(1.2, height - 0.6)), rng.randf_range(-3.0, 3.0))
		lamp.light_color = accent
		lamp.light_energy = rng.randf_range(0.8, 1.7)
		lamp.omni_range = rng.randf_range(4.0, 7.0)
		lamp.shadow_enabled = true
		add_child(lamp)
		light_count += 1
	var beacon: OmniLight3D = OmniLight3D.new()
	beacon.position = Vector3(0.0, height - 0.25, 0.0)
	beacon.light_color = accent
	beacon.light_energy = 2.4
	beacon.omni_range = 6.0
	add_child(beacon)
	light_count += 1

func _build_scatter(rng: RandomNumberGenerator, height: float) -> void:
	var density: int = 5 + int(rng.randf() * 5.0)
	for index: int in range(density):
		var angle: float = rng.randf_range(0.0, TAU)
		var radius: float = rng.randf_range(4.2, 8.0)
		var point: Vector3 = Vector3(cos(angle) * radius, rng.randf_range(0.15, maxf(0.2, height - 0.4)), sin(angle) * radius)
		var kind: int = rng.randi_range(0, 2)
		if kind == 0:
			var rock: MeshInstance3D = MeshInstance3D.new()
			var mesh: SphereMesh = SphereMesh.new(); mesh.radius = rng.randf_range(0.18, 0.55); mesh.height = mesh.radius * 1.3; mesh.radial_segments = 6; mesh.rings = 3
			rock.mesh = mesh; rock.position = point; rock.scale = Vector3(1.0, rng.randf_range(0.5, 1.8), 1.0); rock.material_override = _material(structure.darkened(0.14)); add_child(rock)
		elif kind == 1:
			var post: MeshInstance3D = MeshInstance3D.new()
			var mesh: CylinderMesh = CylinderMesh.new(); mesh.top_radius = 0.08; mesh.bottom_radius = 0.12; mesh.height = rng.randf_range(0.6, 1.6); mesh.radial_segments = 6
			post.mesh = mesh; post.position = point; post.material_override = _material(accent, true); add_child(post)
		else:
			_add_trim(point, Vector3(rng.randf_range(0.3, 0.9), 0.06, rng.randf_range(0.3, 0.9)))
		scatter_count += 1

func _build_ceiling(height: float) -> void:
	var y: float = height + 0.35
	_add_solid_box(Vector3(0.0, y, -3.2), Vector3(7.0, 0.45, 1.5), structure.darkened(0.1))
	_add_solid_box(Vector3(0.0, y, 3.2), Vector3(7.0, 0.45, 1.5), structure.darkened(0.1))
	_add_solid_box(Vector3(-3.2, y, 0.0), Vector3(1.5, 0.45, 5.0), structure.darkened(0.1))
	_add_solid_box(Vector3(3.2, y, 0.0), Vector3(1.5, 0.45, 5.0), structure.darkened(0.1))
	_build_hatch(height)

func _build_hatch(height: float) -> void:
	hatch = Area3D.new()
	hatch.position = Vector3(0.0, height + 0.6, 0.0)
	var collision: CollisionShape3D = CollisionShape3D.new()
	var shape: SphereShape3D = SphereShape3D.new()
	shape.radius = 1.25
	collision.shape = shape
	hatch.add_child(collision)
	add_child(hatch)
	var rim: TorusMesh = TorusMesh.new()
	rim.inner_radius = 1.4
	rim.outer_radius = 1.55
	rim.rings = 8
	rim.ring_segments = 20
	var rim_node: MeshInstance3D = MeshInstance3D.new()
	rim_node.mesh = rim
	rim_node.position = hatch.position
	rim_node.material_override = _material(accent, true)
	add_child(rim_node)
	for index: int in range(4):
		var ray: MeshInstance3D = MeshInstance3D.new()
		var beam: BoxMesh = BoxMesh.new()
		beam.size = Vector3(0.08, 0.08, 2.6)
		ray.mesh = beam
		ray.position = hatch.position + Vector3(cos(float(index) * PI * 0.5) * 1.1, 0.05, sin(float(index) * PI * 0.5) * 1.1)
		ray.rotation.y = float(index) * PI * 0.5
		ray.material_override = _material(accent, true)
		add_child(ray)

func _build_checkpoint(height: float) -> void:
	checkpoint = VysheCheckpoint.new()
	checkpoint.checkpoint_id = int(definition.get("index", 0))
	checkpoint.height_meters = height
	checkpoint.world_seed = int(definition.get("seed", 0))
	checkpoint.section_index = checkpoint.checkpoint_id
	var marker: MeshInstance3D = MeshInstance3D.new()
	var mesh: CylinderMesh = CylinderMesh.new()
	mesh.top_radius = 0.12
	mesh.bottom_radius = 0.12
	mesh.height = 1.4
	mesh.radial_segments = 6
	marker.mesh = mesh
	marker.position = Vector3(0.0, height + 0.7, 0.0)
	marker.material_override = _material(accent, true)
	add_child(marker)

func _add_hold(point: Vector3, normal: Vector3, rest: bool) -> void:
	var mesh: SphereMesh = SphereMesh.new()
	mesh.radius = 0.15
	mesh.height = 0.3
	mesh.radial_segments = 8
	mesh.rings = 4
	var node: MeshInstance3D = MeshInstance3D.new()
	node.mesh = mesh
	node.position = point
	node.material_override = _material(accent if not rest else Color("#ffc247"), true)
	node.set_meta("hold_normal", normal)
	node.set_meta("rest", rest)
	node.set_meta("grapple_hold", true)
	add_child(node)
	var body: StaticBody3D = StaticBody3D.new()
	body.position = point
	var collision: CollisionShape3D = CollisionShape3D.new()
	var shape: SphereShape3D = SphereShape3D.new()
	shape.radius = 0.2
	collision.shape = shape
	body.add_child(collision)
	add_child(body)

func _add_rope(from: Vector3, to: Vector3) -> void:
	var span: Vector3 = to - from
	var mesh: CylinderMesh = CylinderMesh.new()
	mesh.top_radius = 0.025
	mesh.bottom_radius = 0.025
	mesh.height = span.length()
	mesh.radial_segments = 5
	var node: MeshInstance3D = MeshInstance3D.new()
	node.mesh = mesh
	node.position = (from + to) * 0.5
	node.quaternion = Quaternion(Vector3.UP, span.normalized())
	node.material_override = _material(Color("#777b86"))
	add_child(node)

func _add_solid_box(point: Vector3, size: Vector3, color: Color) -> void:
	# Spawn corridor at local x=0,z=2 remains open above the starting pad.
	if point.y < 1.8 and Vector2(point.x, point.z - 2.0).length() < 1.25:
		return
	var mesh: BoxMesh = BoxMesh.new()
	mesh.size = size
	var visual: MeshInstance3D = MeshInstance3D.new()
	visual.mesh = mesh
	visual.position = point
	visual.material_override = surface_material if color == structure else _material(color)
	add_child(visual)
	var body: StaticBody3D = StaticBody3D.new()
	body.position = point
	var collision: CollisionShape3D = CollisionShape3D.new()
	var shape: BoxShape3D = BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)
	add_child(body)

func _add_trim(point: Vector3, size: Vector3) -> void:
	var mesh: BoxMesh = BoxMesh.new()
	mesh.size = size
	var node: MeshInstance3D = MeshInstance3D.new()
	node.mesh = mesh
	node.position = point
	node.material_override = _material(accent, true)
	add_child(node)

func _material(color: Color, emission: bool = false) -> StandardMaterial3D:
	var material: StandardMaterial3D = StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.78
	if emission:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = 1.8
	return material

func _accent_for(zone: String) -> Color:
	if zone == "habitation": return Color("#ff7a1a")
	if zone == "surface": return Color("#a8f02c")
	if zone == "stars" or zone == "galaxy": return Color("#ffc247")
	return Color("#38e0ff")

func _structure_for(zone: String) -> Color:
	if zone == "habitation": return Color("#71675f")
	if zone == "surface": return Color("#55733e")
	if zone == "stars" or zone == "galaxy": return Color("#343956")
	return Color("#4b4650")
