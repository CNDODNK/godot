class_name VysheAudioRuntime
extends Node
var master_bus: int = 0
var sfx_bus: int = -1
var ambient_bus: int = -1
func apply_settings() -> void:
	AudioServer.set_bus_volume_db(master_bus, linear_to_db(float(Settings.values.get("volume", 62)) / 100.0))
