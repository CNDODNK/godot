class_name VysheProceduralAudio
extends Node

var players: Dictionary = {}
var sample_rate: int = 44100

func _ready() -> void:
	for name: String in ["step", "hook", "jump", "checkpoint", "fail"]:
		players[name] = _make_player(name)

func trigger(name: String, intensity: float = 1.0) -> void:
	var player: AudioStreamPlayer = players.get(name)
	if player == null: return
	var stream: AudioStreamGenerator = player.stream as AudioStreamGenerator
	var playback: AudioStreamGeneratorPlayback = player.get_stream_playback() as AudioStreamGeneratorPlayback
	if playback == null: return
	var frequency: float = {"step": 110.0, "hook": 520.0, "jump": 180.0, "checkpoint": 740.0, "fail": 75.0}.get(name, 220.0)
	var duration: float = {"step": 0.08, "hook": 0.16, "jump": 0.24, "checkpoint": 0.42, "fail": 0.55}.get(name, 0.12)
	var frames: int = int(sample_rate * duration)
	for frame: int in range(frames):
		var t: float = float(frame) / sample_rate
		var envelope: float = exp(-t * (12.0 if name != "checkpoint" else 5.0))
		var tone: float = sin(TAU * frequency * t) * envelope * 0.18 * intensity
		if name == "hook": tone += sin(TAU * frequency * 1.85 * t) * envelope * 0.08
		if name == "fail": tone += sin(TAU * frequency * 0.47 * t) * envelope * 0.16
		playback.push_frame(Vector2(tone, tone * 0.92))

func _make_player(name: String) -> AudioStreamPlayer:
	var player: AudioStreamPlayer = AudioStreamPlayer.new()
	player.name = "Procedural_" + name
	var stream: AudioStreamGenerator = AudioStreamGenerator.new()
	stream.mix_rate = sample_rate
	stream.buffer_length = 0.6
	player.stream = stream
	player.bus = "SFX"
	add_child(player)
	player.play()
	return player
