class_name VysheEnhancedEffects
extends Node3D
## Визуальный слой сцены. Не влияет на физику и не требует внешних ассетов.

const Profile = preload("res://data/graphics_preset.gd")
const WATER = preload("res://shaders/water.gdshader")
const SHAFT = preload("res://shaders/fog_shafts.gdshader")
const PALETTES: Array[Color] = [Color("#719dc9"), Color("#e2a168"), Color("#a497ef")]
const SPARK_POOL: int = 4
@export var water_enabled: bool = true
@export var grade_strength: float = 0.55
var dust: GPUParticles3D
var shafts: Node3D
var water: MeshInstance3D
var lamp: SpotLight3D
var sparks: Array[GPUParticles3D] = []
var next_spark: int = 0
var palette_index: int = 0
var grade_lut: ImageTexture
var modern_features: bool = false
var configured: bool = false
var particles_active: bool = false
var elapsed: float = 0.0

func _ready() -> void:
	var bus: Node = get_node_or_null("/root/EventBus")
	if bus != null:
		bus.connect(&"hook_attached", spawn_sparks)
	modern_features = RenderingServer.get_current_rendering_method() == "forward_plus"
	grade_lut = _build_lut()
	lamp = SpotLight3D.new()
	lamp.position = Vector3(0.8, 6.8, -2.0)
	lamp.rotation_degrees.x = -90.0
	lamp.spot_range = 12.0
	lamp.spot_angle = 37.0
	add_child(lamp)
	shafts = Node3D.new()
	add_child(shafts)
	for x: float in [-3.0, 0.8]:
		var beam: CylinderMesh = CylinderMesh.new()
		beam.top_radius = 0.21
		beam.bottom_radius = 1.35
		beam.height = 6.5
		beam.radial_segments = 12
		beam.cap_top = false
		beam.cap_bottom = false
		var shaft: MeshInstance3D = _surface(beam, SHAFT, Vector3(x, 3.45, -2.0))
		shafts.add_child(shaft)
	var plane: PlaneMesh = PlaneMesh.new()
	plane.size = Vector2(5.0, 2.7)
	water = _surface(plane, WATER, Vector3(1.3, 0.045, 1.6))
	add_child(water)
	water.material_override.set_shader_parameter("reflection_strength", 0.55 if modern_features else 0.28)
	dust = _particles(false)
	dust.position = Vector3(0.0, 3.0, -1.2)
	for index: int in range(SPARK_POOL):
		sparks.append(_particles(true))
	_set_active(false, false, false, false)

func apply_profile(profile: Profile, particles_allowed: bool = true, shafts_allowed: bool = true, water_allowed: bool = true) -> void:
	configured = profile.bloom_enabled or profile.volumetric_light_enabled or profile.particles_enabled
	_set_active(profile.particles_enabled and particles_allowed, profile.volumetric_light_enabled and shafts_allowed, configured and water_enabled and water_allowed, configured)
	lamp.shadow_enabled = profile.shadows_enabled

func set_altitude(altitude: float) -> void:
	palette_index = 0 if altitude < -100.0 else (1 if altitude < 400.0 else 2)
	lamp.light_color = PALETTES[palette_index]

func spawn_sparks(_index: int, point: Vector3) -> void:
	if not particles_active or not is_visible_in_tree():
		return
	var emitter: GPUParticles3D = sparks[next_spark]
	next_spark = (next_spark + 1) % sparks.size()
	emitter.global_position = point
	emitter.restart()
	emitter.emitting = true

func _process(delta: float) -> void:
	elapsed += delta
	lamp.light_energy = 3.3 + 0.24 * sin(elapsed * 11.3) * sin(elapsed * 17.9)

func _set_active(particles: bool, beams: bool, puddle: bool, light: bool) -> void:
	particles_active = particles
	dust.visible = particles
	dust.emitting = particles
	for emitter: GPUParticles3D in sparks:
		emitter.visible = particles
		if not particles:
			emitter.emitting = false
	shafts.visible = beams
	water.visible = puddle
	lamp.visible = light
	set_process(light)

func _surface(mesh: Mesh, shader: Shader, origin: Vector3) -> MeshInstance3D:
	var instance: MeshInstance3D = MeshInstance3D.new()
	var material: ShaderMaterial = ShaderMaterial.new()
	material.shader = shader
	instance.material_override = material
	instance.mesh = mesh
	instance.position = origin
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return instance

func _particles(burst: bool) -> GPUParticles3D:
	var emitter: GPUParticles3D = GPUParticles3D.new()
	emitter.emitting = false
	emitter.one_shot = burst
	emitter.explosiveness = 1.0 if burst else 0.0
	emitter.amount = 18 if burst else (96 if modern_features else 36)
	emitter.lifetime = 0.44 if burst else 6.0
	emitter.preprocess = 0.0 if burst else 4.0
	emitter.visibility_aabb = AABB(Vector3(-6, -5, -5), Vector3(12, 10, 10))
	var motion: ParticleProcessMaterial = ParticleProcessMaterial.new()
	motion.gravity = Vector3.DOWN * (8.0 if burst else 0.04)
	motion.initial_velocity_min = 2.0 if burst else 0.03
	motion.initial_velocity_max = 5.0 if burst else 0.18
	motion.spread = 75.0
	motion.direction = Vector3.UP
	if not burst:
		motion.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
		motion.emission_box_extents = Vector3(4.4, 2.8, 3.4)
	emitter.process_material = motion
	var mesh: BoxMesh = BoxMesh.new()
	mesh.size = Vector3(0.025, 0.075, 0.025) if burst else Vector3.ONE * 0.028
	var material: StandardMaterial3D = StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color("#ffc263") if burst else Color("#b1a084")
	mesh.material = material
	emitter.draw_pass_1 = mesh
	add_child(emitter)
	return emitter

func _build_lut() -> ImageTexture:
	var image: Image = Image.create(256, PALETTES.size(), false, Image.FORMAT_RGB8)
	for row: int in range(PALETTES.size()):
		for column: int in range(256):
			var value: float = column / 255.0
			var amount: float = 0.42 * (1.0 - value)
			var tint: Color = Color.WHITE.lerp(PALETTES[row], amount)
			image.set_pixel(column, row, tint * value)
	return ImageTexture.create_from_image(image)
