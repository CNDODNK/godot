class_name VysheBackdrop
extends Node3D

const PALETTES: Array[Color] = [Color("#0b101c"), Color("#2b1b24"), Color("#7896b9"), Color("#171e40"), Color("#050712")]
var stars: MultiMeshInstance3D
var cave_walls: Node3D
var cave_mist: Array[MeshInstance3D] = []
var cloud_layers: Array[MeshInstance3D] = []
var cave_lights: Array[OmniLight3D] = []
var current_zone: int = -1
var time: float = 0.0

func _ready() -> void:
	_build_cave()
	_build_stars()
	_build_clouds()
	_apply_zone(0)

func set_height(height: float) -> void:
	global_position.y = height

func set_player_position(point: Vector3) -> void:
	global_position.x = point.x
	global_position.z = point.z
	var zone: int = _zone_for(point.y)
	_apply_zone(zone)

func _process(delta: float) -> void:
	time += delta
	for index: int in range(cloud_layers.size()): cloud_layers[index].rotation.y += delta * (0.002 + index * 0.001)
	if stars: stars.rotation.y += delta * 0.004
	for index: int in range(cave_lights.size()): cave_lights[index].light_energy = 1.0 + sin(time * (2.0 + index * 0.3)) * 0.18
	for index: int in range(cave_mist.size()): cave_mist[index].position.x += sin(time * 0.12 + index) * delta * 0.08


func _zone_for(height: float) -> int:
	if height < -100.0: return 0
	if height < 0.0: return 1
	if height < 200.0: return 2
	if height < 500.0: return 3
	return 4
func _build_cave() -> void:
	cave_walls = Node3D.new()
	add_child(cave_walls)
	var wall_material: StandardMaterial3D = StandardMaterial3D.new()
	wall_material.cull_mode = BaseMaterial3D.CULL_DISABLED
	wall_material.albedo_color = Color("#1a1d2c")
	wall_material.roughness = 1.0
	var wall: CylinderMesh = CylinderMesh.new()
	wall.top_radius = 15.0; wall.bottom_radius = 18.0; wall.height = 24.0; wall.radial_segments = 18; wall.cap_top = false; wall.cap_bottom = false
	var shell: MeshInstance3D = MeshInstance3D.new(); shell.mesh = wall; shell.material_override = wall_material; shell.position.y = 6.0; shell.scale = Vector3(1.0, 1.0, 1.0); cave_walls.add_child(shell)
	var ceiling: CylinderMesh = CylinderMesh.new()
	ceiling.top_radius = 10.0; ceiling.bottom_radius = 10.0; ceiling.height = 0.35; ceiling.radial_segments = 18
	var ceiling_node: MeshInstance3D = MeshInstance3D.new(); ceiling_node.mesh = ceiling; ceiling_node.position.y = 12.0; ceiling_node.material_override = wall_material; cave_walls.add_child(ceiling_node)
	for index: int in range(5):
		var fog_mesh: QuadMesh = QuadMesh.new(); fog_mesh.size = Vector2(12.0 + index * 3.0, 5.0)
		var fog_material: StandardMaterial3D = StandardMaterial3D.new(); fog_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA; fog_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED; fog_material.albedo_color = Color(0.22, 0.28, 0.42, 0.055)
		fog_mesh.material = fog_material
		var fog: MeshInstance3D = MeshInstance3D.new(); fog.mesh = fog_mesh; fog.position = Vector3(-7.0 + index * 3.6, 2.0 + index * 1.2, -8.0 - index); fog.rotation.x = -PI * 0.08; add_child(fog); cave_mist.append(fog)
	for index: int in range(4):
		var lamp: OmniLight3D = OmniLight3D.new(); lamp.position = Vector3(cos(float(index) * TAU / 4.0) * 8.0, 3.0 + (index % 2) * 3.0, sin(float(index) * TAU / 4.0) * 8.0); lamp.light_color = Color("#38e0ff") if index % 2 == 0 else Color("#ff3d8e"); lamp.light_energy = 1.2; lamp.omni_range = 10.0; add_child(lamp); cave_lights.append(lamp)

func _build_stars() -> void:
	var multi: MultiMesh = MultiMesh.new(); multi.transform_format = MultiMesh.TRANSFORM_3D; multi.instance_count = 180
	var mesh: QuadMesh = QuadMesh.new(); mesh.size = Vector2(0.06, 0.06)
	var material: StandardMaterial3D = StandardMaterial3D.new(); material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED; material.albedo_color = Color("#d9e7ff"); mesh.material = material; multi.mesh = mesh
	stars = MultiMeshInstance3D.new(); stars.multimesh = multi; stars.position = Vector3(0, 3, 0); add_child(stars)
	var rng: RandomNumberGenerator = RandomNumberGenerator.new(); rng.seed = 424242
	for index: int in range(multi.instance_count): multi.set_instance_transform(index, Transform3D(Basis.IDENTITY, Vector3(rng.randf_range(-28, 28), rng.randf_range(-2, 24), rng.randf_range(-28, 28))))

func _build_clouds() -> void:
	for index: int in range(3):
		var mesh: QuadMesh = QuadMesh.new(); mesh.size = Vector2(34.0 + index * 10.0, 16.0 + index * 4.0)
		var material: StandardMaterial3D = StandardMaterial3D.new(); material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA; material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED; material.albedo_color = Color(0.8, 0.88, 1.0, 0.12); mesh.material = material
		var cloud: MeshInstance3D = MeshInstance3D.new(); cloud.mesh = mesh; cloud.position = Vector3(0, 8 + index * 5, -10 - index * 5); cloud.rotation.x = -PI * 0.5; add_child(cloud); cloud_layers.append(cloud)

func _apply_zone(zone: int) -> void:
	if zone == current_zone: return
	current_zone = zone
	var environment: WorldEnvironment = get_parent().get_node_or_null("Environment") as WorldEnvironment
	if environment != null: environment.environment.background_color = PALETTES[zone]
	if cave_walls: cave_walls.visible = zone < 2
	for fog: MeshInstance3D in cave_mist: fog.visible = zone < 2
	for lamp: OmniLight3D in cave_lights: lamp.visible = zone < 2
	if stars: stars.visible = zone >= 2
	for cloud: MeshInstance3D in cloud_layers: cloud.visible = zone == 2 or zone == 3
