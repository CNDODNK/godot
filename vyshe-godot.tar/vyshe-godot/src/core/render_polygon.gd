class_name VysheRenderPolygon
extends Node3D
## Процедурный полигон для визуальной проверки PS1-пайплайна.

@export var surface_material: ShaderMaterial
var materials: Array[ShaderMaterial] = []
var lamp: OmniLight3D
var panel_texture: ImageTexture
var phase: float = 0.0

func _ready() -> void:
	panel_texture = _make_panel_texture()
	_build_floor()
	_build_columns()
	_build_hanging_rings()
	_build_lighting()

func _process(delta: float) -> void:
	phase += delta
	rotation.y = sin(phase * 0.17) * 0.025

func _make_mesh(mesh: Mesh, position: Vector3, color: Color) -> MeshInstance3D:
	var instance: MeshInstance3D = MeshInstance3D.new()
	instance.mesh = mesh
	instance.position = position
	var material: ShaderMaterial = surface_material.duplicate() as ShaderMaterial
	material.set_shader_parameter("albedo_color", color)
	material.set_shader_parameter("albedo_texture", panel_texture)
	materials.append(material)
	instance.material_override = material
	add_child(instance)
	return instance

func _build_floor() -> void:
	var floor: BoxMesh = BoxMesh.new()
	floor.size = Vector3(18.0, 0.35, 18.0)
	_make_mesh(floor, Vector3(0.0, -0.2, 0.0), Color("#5b453a"))
	for index: int in range(8):
		var slab: BoxMesh = BoxMesh.new()
		slab.size = Vector3(1.7, 0.08, 0.12)
		_make_mesh(slab, Vector3(-5.8 + float(index) * 1.7, 0.02, -2.4), Color("#d28b45"))

func _build_columns() -> void:
	for index: int in range(6):
		var column: CylinderMesh = CylinderMesh.new()
		column.top_radius = 0.45 + float(index % 2) * 0.18
		column.bottom_radius = column.top_radius * 1.15
		column.radial_segments = 8
		column.rings = 0
		column.height = 3.0 + float(index % 3) * 0.65
		var angle: float = float(index) / 6.0 * TAU
		var radius: float = 5.6
		_make_mesh(column, Vector3(cos(angle) * radius, column.height * 0.5, sin(angle) * radius), Color("#4f6875"))

func _build_hanging_rings() -> void:
	for index: int in range(5):
		var ring: TorusMesh = TorusMesh.new()
		ring.inner_radius = 0.42
		ring.outer_radius = 0.52
		ring.rings = 8
		ring.ring_segments = 12
		var angle: float = float(index) / 5.0 * TAU
		var node: MeshInstance3D = _make_mesh(ring, Vector3(cos(angle) * 3.0, 3.0 + float(index % 2), sin(angle) * 3.0), Color("#e3a342"))
		node.rotation.x = PI * 0.5

func _build_lighting() -> void:
	lamp = OmniLight3D.new()
	lamp.light_color = Color("#ffad5c")
	lamp.light_energy = 2.0
	lamp.omni_range = 12.0
	lamp.position = Vector3(0.0, 4.5, 0.0)
	add_child(lamp)

func _make_panel_texture() -> ImageTexture:
	const SIDE: int = 64
	var image: Image = Image.create(SIDE, SIDE, false, Image.FORMAT_RGB8)
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 1997
	for y: int in range(SIDE):
		for x: int in range(SIDE):
			var tone: float = rng.randf_range(0.70, 1.0)
			if x % 16 == 0 or y % 16 == 0:
				tone *= 0.52
			image.set_pixel(x, y, Color(tone, tone, tone))
	return ImageTexture.create_from_image(image)
