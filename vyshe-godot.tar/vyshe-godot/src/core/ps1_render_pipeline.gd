class_name VyshePs1RenderPipeline
extends Control
## Переключает профили и выводит единственную копию внутреннего буфера.

const Profile = preload("res://data/graphics_preset.gd")
const Effects = preload("res://src/core/enhanced_effects.gd")
const PREVIEW_ALTITUDES: Array[float] = [-300.0, 30.0, 450.0]
const Polygon = preload("res://src/core/render_polygon.gd")
const PROFILES: Array[Profile] = [
	preload("res://data/graphics_ps1_pure.tres"),
	preload("res://data/graphics_ps1_enhanced.tres"),
	preload("res://data/graphics_modern_retro.tres"),
]

signal preset_changed(profile: Profile)

@onready var internal_viewport: SubViewport = $InternalViewport
@onready var world: Polygon = $InternalViewport/World
@onready var effects: Effects = $InternalViewport/World/EnhancedEffects
@onready var environment: WorldEnvironment = $InternalViewport/World/Environment
@onready var post_rect: TextureRect = $PostRect
@onready var post_material: ShaderMaterial = post_rect.material as ShaderMaterial
@onready var readout: Label = $Readout

var profile_index: int = 1
var preview_stratum: int = 0
var particles_allowed: bool = true
var shafts_allowed: bool = true
var water_allowed: bool = true
var crt_enabled: bool = true
var snapping_enabled: bool = true

func _ready() -> void:
	post_rect.texture = internal_viewport.get_texture()
	post_material.set_shader_parameter("grade_lut", effects.grade_lut)
	resized.connect(_fit_picture)
	select_profile(profile_index)

func select_profile(index: int) -> void:
	profile_index = posmod(index, PROFILES.size())
	_apply_profile()
	preset_changed.emit(PROFILES[profile_index])

func _unhandled_key_input(event: InputEvent) -> void:
	var key: InputEventKey = event as InputEventKey
	if key == null or not key.pressed or key.echo:
		return
	match key.physical_keycode:
		KEY_1: select_profile(0)
		KEY_2: select_profile(1)
		KEY_3: select_profile(2)
		KEY_B: select_preview_stratum(preview_stratum + 1)
		KEY_F: effects.spawn_sparks(0, Vector3(0.8, 0.65, -1.9))
		KEY_P:
			particles_allowed = not particles_allowed
			_apply_profile()
		KEY_L:
			shafts_allowed = not shafts_allowed
			_apply_profile()
		KEY_O:
			water_allowed = not water_allowed
			_apply_profile()
		KEY_C:
			crt_enabled = not crt_enabled
			_apply_profile()
		KEY_V:
			snapping_enabled = not snapping_enabled
			_apply_profile()

func select_preview_stratum(index: int) -> void:
	preview_stratum = posmod(index, PREVIEW_ALTITUDES.size())
	effects.set_altitude(PREVIEW_ALTITUDES[preview_stratum])
	post_material.set_shader_parameter("grade_row", (effects.palette_index + 0.5) / PREVIEW_ALTITUDES.size())

func _apply_profile() -> void:
	var profile: Profile = PROFILES[profile_index]
	internal_viewport.size = profile.internal_size
	for material: ShaderMaterial in world.materials:
		material.set_shader_parameter("vertex_snap_strength", profile.vertex_snap_strength if snapping_enabled else 0.0)
		material.set_shader_parameter("snap_resolution", Vector2(profile.internal_size) * 0.5)
		material.set_shader_parameter("fog_amount", profile.fog_strength)
		material.set_shader_parameter("affine_strength", profile.vertex_snap_strength)
	world.lamp.shadow_enabled = profile.shadows_enabled
	effects.apply_profile(profile, particles_allowed, shafts_allowed, water_allowed)
	select_preview_stratum(preview_stratum)
	environment.environment.glow_enabled = profile.bloom_enabled and effects.modern_features
	environment.environment.ssao_enabled = profile_index == 2 and effects.modern_features
	post_material.set_shader_parameter("grade_strength", effects.grade_strength if effects.configured else 0.0)
	post_material.set_shader_parameter("internal_resolution", Vector2(profile.internal_size))
	post_material.set_shader_parameter("dither_strength", profile.dither_strength)
	post_material.set_shader_parameter("crt_strength", profile.crt_strength if crt_enabled else 0.0)
	readout.text = "Шахта   /   Графический полигон\n%s   %d × %d\n1–3  Профиль   C  CRT   V  Дрожание PS1\nB  Палитра   F  Искры\nP  Частицы   L  Лучи   O  Вода" % [profile.preset_name, profile.internal_size.x, profile.internal_size.y]
	_fit_picture()

func _fit_picture() -> void:
	var native: Vector2 = Vector2(internal_viewport.size)
	var ratio: float = minf(size.x / native.x, size.y / native.y)
	if ratio >= 1.0:
		ratio = floorf(ratio)
	post_rect.size = (native * ratio).floor()
	post_rect.position = ((size - post_rect.size) * 0.5).floor()
	readout.position = post_rect.position + Vector2(12.0, 8.0)
