class_name VysheRopeVisual
extends MeshInstance3D
@export var radius: float = 0.012
func update_rope(start_point: Vector3, end_point: Vector3) -> void:
	var span: Vector3 = end_point - start_point
	if span.length_squared() < 0.000001: visible = false; return
	visible = true
	global_position = start_point + span * 0.5
	scale = Vector3(1.0, span.length(), 1.0)
	quaternion = Quaternion(Vector3.UP, span.normalized())
