class_name VysheRopeSolver
extends RefCounted

const Tuning = preload("res://src/grapple/hook_tuning.gd")

static func constrain(body: CharacterBody3D, anchor: Vector3, tuning: Tuning, delta: float) -> void:
	for iteration: int in range(tuning.solver_iterations):
		var offset: Vector3 = body.global_position - anchor
		var distance: float = offset.length()
		if distance < 0.00001:
			return
		var normal: Vector3 = offset / distance
		if distance > tuning.rope_length:
			body.move_and_collide(-normal * minf(distance - tuning.rope_length, tuning.correction_speed * delta))
			body.velocity -= normal * maxf(0.0, body.velocity.dot(normal))
		elif distance < tuning.minimum_distance:
			body.move_and_collide(normal * (tuning.minimum_distance - distance) * 0.5)
		else:
			return
