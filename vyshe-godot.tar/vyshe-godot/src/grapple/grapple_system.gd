class_name VysheGrappleSystem
extends Node
signal rest_started
@export var hook_1: VysheGrappleHook
@export var hook_2: VysheGrappleHook
var resting: bool = false
func attached_count() -> int:
	return int(hook_1 != null and hook_1.is_attached) + int(hook_2 != null and hook_2.is_attached)
func update_resting(speed: float, stamina: VysheStaminaComponent) -> void:
	var now: bool = attached_count() == 2 and speed < 0.71
	if now and not resting: rest_started.emit()
	resting = now
	if resting and stamina.value < stamina.maximum: stamina.value = minf(stamina.maximum, stamina.value + 8.0 * get_physics_process_delta_time())
