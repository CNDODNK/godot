class_name VysheGrappleHook
extends Node

signal attached(point: Vector3)
signal released()

enum State { IDLE, FIRING, ATTACHED, RETRACTING }
var state: State = State.IDLE
var anchor: Vector3
var is_attached: bool:
	get: return state == State.ATTACHED

func fire(world: World3D, query: PhysicsRayQueryParameters3D) -> Vector3:
	var was_attached: bool = is_attached
	state = State.FIRING
	var hit: Dictionary = world.direct_space_state.intersect_ray(query)
	if hit.is_empty():
		state = State.ATTACHED if was_attached else State.IDLE
		release()
		return Vector3.ZERO
	anchor = hit["position"]
	state = State.ATTACHED
	attached.emit(anchor)
	return hit["normal"]

func release() -> void:
	if is_attached:
		state = State.RETRACTING
		released.emit()
		state = State.IDLE
