class_name VysheHookTuning
extends Resource
@export var reach: float = 3.0
@export var rope_length: float = 2.4
@export var pull_force: float = 15.0
@export var swing_force: float = 10.0
@export var lower_force: float = 8.0
@export var tangent_damp: float = 0.1
@export var radial_damp: float = 1.35
@export var pull_speed_cap: float = 3.1
@export var speed_cap: float = 7.5
@export var top_out_distance: float = 0.75
@export var top_out_boost: float = 16.0
@export var attach_cost: float = 1.2
@export var assist_cap: float = 4.0
@export var assist_scale: float = 2.0
@export var assist_normal: float = 0.35
@export var assist_drop: float = 1.0
@export var correction_speed: float = 9.0
@export var minimum_distance: float = 0.28
@export var solver_iterations: int = 3
@export_flags_3d_physics var target_mask: int = 1
