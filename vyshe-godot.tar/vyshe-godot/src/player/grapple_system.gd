class_name VyshePlayerGrappleSystem
extends Node
const Hook = preload("res://src/grapple/grapple_hook.gd")
@onready var left: Hook = $Left
@onready var right: Hook = $Right
var left_model: Node3D
var right_model: Node3D

func _ready() -> void:
	left_model = _build_hook(Color("#38e0ff"), -1.0)
	right_model = _build_hook(Color("#ff3d8e"), 1.0)

func _process(_delta: float) -> void:
	_update_model(left_model, left, -1.0)
	_update_model(right_model, right, 1.0)

func hook(index: int) -> Hook: return left if index == 0 else right
func count() -> int: return int(left.is_attached) + int(right.is_attached)
func release_all() -> void: left.release(); right.release()

func _build_hook(accent: Color, side: float) -> Node3D:
	var root: Node3D = Node3D.new()
	root.position = Vector3(side * 0.34, -0.48, -0.48)
	var material: StandardMaterial3D = StandardMaterial3D.new()
	material.albedo_color = Color("#a6adb7")
	material.metallic = 0.65
	var accent_material: StandardMaterial3D = StandardMaterial3D.new()
	accent_material.albedo_color = accent
	accent_material.emission_enabled = true
	accent_material.emission = accent
	var body: CylinderMesh = CylinderMesh.new()
	body.top_radius = 0.045; body.bottom_radius = 0.07; body.height = 0.18; body.radial_segments = 6
	var mesh: MeshInstance3D = MeshInstance3D.new(); mesh.mesh = body; mesh.material_override = material; root.add_child(mesh)
	var ring: TorusMesh = TorusMesh.new()
	ring.inner_radius = 0.045; ring.outer_radius = 0.065; ring.rings = 6; ring.ring_segments = 10
	var ring_mesh: MeshInstance3D = MeshInstance3D.new(); ring_mesh.mesh = ring; ring_mesh.material_override = accent_material; ring_mesh.rotation.x = PI * 0.5; ring_mesh.position.y = 0.1; root.add_child(ring_mesh)
	var prongs: Array[MeshInstance3D] = []
	for index: int in range(3):
		var prong: BoxMesh = BoxMesh.new(); prong.size = Vector3(0.035, 0.035, 0.18)
		var prong_mesh: MeshInstance3D = MeshInstance3D.new(); prong_mesh.mesh = prong; prong_mesh.material_override = material; prong_mesh.position = Vector3(0.0, -0.02, -0.12); prong_mesh.rotation.y = float(index) * TAU / 3.0 + side * 0.3; root.add_child(prong_mesh); prongs.append(prong_mesh)
	root.set_meta("prongs", prongs)
	camera_add(root)
	return root

func camera_add(node: Node3D) -> void:
	var camera: Camera3D = get_parent().get_node("CameraRig") as Camera3D
	camera.add_child(node)

func _update_model(model: Node3D, hook: Hook, side: float) -> void:
	if model == null: return
	var rest: Vector3 = Vector3(side * 0.34, -0.48, -0.48)
	var target: Vector3 = rest
	if hook.is_attached:
		target = model.get_parent().to_local(hook.anchor)
		target.z = minf(target.z, -0.24)
	model.position = model.position.lerp(target, 0.18)
	model.rotation.z = sin(Time.get_ticks_msec() * 0.004 + side) * 0.04

func _exit_tree() -> void:
	left_model = null; right_model = null
