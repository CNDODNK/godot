class_name VyshePlayerController
extends CharacterBody3D
const MovementTuning = preload("res://src/player/movement_tuning.gd")
const HookTuning = preload("res://src/grapple/hook_tuning.gd")
const StaminaComponent = preload("res://src/player/stamina_component.gd")
const GrappleHook = preload("res://src/grapple/grapple_hook.gd")
const RopeSolver = preload("res://src/grapple/rope_solver.gd")
const CameraRig = preload("res://src/player/camera_rig.gd")
const EventBusService = preload("res://autoload/event_bus.gd")
var event_bus: Node = EventBusService.new()
@export var movement: MovementTuning
@export var hook_tuning: HookTuning
@onready var stamina: StaminaComponent = $Stamina
@onready var grapples: Node = $GrappleSystem
@onready var camera: CameraRig = $CameraRig
var coyote: float = 0.0
var targeting: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.new()
func _ready() -> void:
	targeting.exclude = [get_rid()]
func _physics_process(delta: float) -> void:
	var axis: Vector2 = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var grounded: bool = is_on_floor()
	coyote = movement.coyote_time if grounded else maxf(0.0, coyote - delta)
	if Input.is_action_just_pressed("hook_1"): fire_hook(0)
	if Input.is_action_just_pressed("hook_2"): fire_hook(1)
	if Input.is_action_just_pressed("jump"): _play_local_sound("jump")
	if Input.is_action_just_pressed("release_1"): grapples.left.release()
	if Input.is_action_just_pressed("release_2"): grapples.right.release()
	if Input.is_action_just_pressed("jump") and (grounded or coyote > 0.0 or grapples.count() > 0) and stamina.value >= movement.jump_cost: _jump()
	var forward: bool = Input.is_action_pressed("move_forward")
	var back: bool = Input.is_action_pressed("move_back")
	if grapples.count() > 0: _hang(delta, axis.x, forward, back)
	else: _walk(delta, axis, grounded); velocity.y -= movement.gravity * delta
	move_and_slide()
	if grapples.count() > 0:
		RopeSolver.constrain(self, grapples.left.anchor, hook_tuning, delta) if grapples.left.is_attached else null
		RopeSolver.constrain(self, grapples.right.anchor, hook_tuning, delta) if grapples.right.is_attached else null
	stamina.tick(delta, is_on_floor(), grapples.count() > 0, forward, axis.x, global_position.y - 0.85)
func _play_local_sound(name: String) -> void:
	var stream: AudioStreamGenerator = AudioStreamGenerator.new()
	stream.mix_rate = 44100.0
	stream.buffer_length = 0.35
	var player_audio: AudioStreamPlayer = AudioStreamPlayer.new()
	player_audio.stream = stream
	player_audio.bus = "SFX"
	add_child(player_audio)
	player_audio.play()
	var playback: AudioStreamGeneratorPlayback = player_audio.get_stream_playback() as AudioStreamGeneratorPlayback
	if playback == null: return
	var frequency: float = 180.0 if name == "jump" else 520.0
	for frame: int in range(8000):
		var t: float = float(frame) / 44100.0
		var envelope: float = exp(-t * 12.0)
		var value: float = sin(TAU * frequency * t) * envelope * 0.18
		playback.push_frame(Vector2(value, value))
	player_audio.finished.connect(player_audio.queue_free)
func fire_hook(index: int) -> void:
	if stamina.exhausted: return
	var hook: GrappleHook = grapples.hook(index)
	targeting.from = camera.global_position
	targeting.to = targeting.from + Vector3.FORWARD.rotated(Vector3.RIGHT, camera.pitch).rotated(Vector3.UP, rotation.y) * hook_tuning.reach
	var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(targeting)
	if hit.is_empty(): hook.release(); return
	var collider: Object = hit.get("collider")
	if collider == null:
		hook.release()
		return
	# HTML-поведение: любой физический surface под прицелом пригоден для крюка.
	# Специальные holds сохраняют rest-метаданные, но больше не являются единственными целями.
	hook.anchor = hit.position
	hook.state = GrappleHook.State.ATTACHED
	hook.attached.emit(hook.anchor)
	event_bus.hook_attached.emit(index, hook.anchor)
	stamina.spend(hook_tuning.attach_cost)
func _walk(delta: float, axis: Vector2, grounded: bool) -> void:
	var direction: Vector3 = global_basis * Vector3(axis.x, 0.0, axis.y)
	var horizontal: Vector3 = Vector3(velocity.x, 0.0, velocity.z)
	if grounded: horizontal = horizontal.lerp(direction * movement.walk_speed, minf(1.0, movement.walk_response * delta))
	else: horizontal = (horizontal + direction * movement.air_accel * delta).limit_length(movement.air_cap)
	velocity.x = horizontal.x; velocity.z = horizontal.z
func _hang(delta: float, side: float, forward: bool, back: bool) -> void:
	var hook: GrappleHook = grapples.left if grapples.left.is_attached else grapples.right
	var pull: Vector3 = (hook.anchor - global_position).normalized()
	var radial: Vector3 = pull * velocity.dot(pull)
	velocity = (velocity - radial) * maxf(0.0, 1.0 - hook_tuning.tangent_damp * delta) + radial * maxf(0.0, 1.0 - hook_tuning.radial_damp * delta)
	var force: Vector3 = -Vector3.UP * movement.gravity + global_basis.x * side * hook_tuning.swing_force
	if forward: force += pull * hook_tuning.pull_force
	if back: force -= pull * hook_tuning.lower_force
	velocity = (velocity + force * delta).limit_length(hook_tuning.speed_cap)
func _jump() -> void:
	var look_up: float = maxf(0.0, sin(camera.pitch)); var cap: float = movement.hook_jump_cap if grapples.count() > 0 else movement.ground_jump_cap
	grapples.release_all(); velocity = Vector3(velocity.x, movement.jump_speed + look_up * movement.jump_look_bonus, velocity.z)
	var horizontal: Vector3 = (velocity - global_basis.z * (movement.jump_push + look_up * movement.jump_look_push)).limit_length(cap)
	velocity.x = horizontal.x; velocity.z = horizontal.z; stamina.spend(movement.jump_cost); coyote = 0.0
