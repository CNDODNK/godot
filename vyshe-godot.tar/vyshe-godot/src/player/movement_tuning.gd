class_name VysheMovementTuning
extends Resource
@export var gravity: float = 11.0
@export var walk_speed: float = 3.3
@export var air_accel: float = 7.0
@export var jump_speed: float = 5.05
@export var jump_cost: float = 10.0
@export var jump_look_bonus: float = 0.95
@export var jump_vertical_keep: float = 0.6
@export var jump_push: float = 1.9
@export var jump_look_push: float = 0.9
@export var ground_jump_cap: float = 6.5
@export var hook_jump_cap: float = 10.5
@export var air_cap: float = 12.0
@export var walk_response: float = 14.0
@export var ground_friction: float = 12.0
@export var coyote_time: float = 0.12
