class_name VysheStaminaComponent
extends Node

signal depleted()
@export var maximum: float = 100.0
@export var regen_ground: float = 22.0
@export var drain_hook: float = 3.0
@export var drain_pull: float = 8.5
@export var drain_swing: float = 1.5
@export var swing_threshold: float = 0.2
@export var recovery_rate: float = 2.0
@export var recovery_threshold: float = 15.0
@export var altitude_scale: float = 2200.0
@export var altitude_cap: float = 0.45
var value: float = 100.0
var exhausted: bool = false

func spend(amount: float) -> void:
	value = maxf(0.0, value - amount)

func tick(delta: float, grounded: bool, hooked: bool, pulling: bool, side: float, altitude: float) -> void:
	var rate: float = 0.0
	if grounded:
		rate = regen_ground
	elif hooked:
		var multiplier: float = 1.0 + clampf(altitude / altitude_scale, 0.0, altitude_cap)
		rate = -(drain_hook + (drain_pull if pulling else 0.0)) * multiplier
		if absf(side) > swing_threshold:
			rate -= drain_swing
	elif exhausted:
		rate = recovery_rate
	value = clampf(value + rate * delta, 0.0, maximum)
	if hooked and value <= 0.0 and not exhausted:
		exhausted = true
		depleted.emit()
	if value >= recovery_threshold:
		exhausted = false
