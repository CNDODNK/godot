class_name VysheCameraRig
extends Camera3D

@export var sensitivity: float = 0.0022
@export var jitter_enabled: bool = true
var pitch: float = 0.12
var base_height: float
var phase: float = 0.0
var dip: float = 0.0
var dip_velocity: float = 0.0
var body: CharacterBody3D

func _ready() -> void:
	body = get_parent() as CharacterBody3D
	base_height = position.y
	rotation.x = pitch
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		look((event as InputEventMouseMotion).relative)
	elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	elif event is InputEventMouseButton and event.pressed and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func look(relative: Vector2) -> void:
	body.rotate_y(-relative.x * sensitivity)
	pitch = clampf(pitch - relative.y * sensitivity, -1.5, 1.5)
	rotation.x = pitch

func _process(delta: float) -> void:
	phase += delta
	var step: float = minf(delta, 0.033)
	dip_velocity += (-dip * 90.0 - dip_velocity * 9.0) * step
	dip += dip_velocity * step
	var speed: float = Vector2(body.velocity.x, body.velocity.z).length()
	var bob: float = sin(phase * 1.8) * 0.007
	if body.is_on_floor() and speed > 0.4: bob = sin(phase * 9.0) * 0.03 * minf(speed / 3.3, 1.0)
	position.y = base_height + bob + dip
	rotation.z = lerpf(rotation.z, clampf(-body.velocity.dot(body.global_basis.x) * 0.016, -0.09, 0.09), clampf(delta * 10.0, 0.0, 1.0))
	if jitter_enabled: rotation.z += sin(phase * 29.0) * 0.001
	fov = lerpf(fov, 74.0 + clampf((-body.velocity.y - 7.0) * 1.1, 0.0, 10.0), clampf(4.0 * delta, 0.0, 1.0))
