class_name VysheInputService
extends Node
## Единая точка доступа к действиям. Карта действий создаётся без логики в UI.

const ACTIONS: Array[String] = ["look", "hook_1", "hook_2", "release_1", "release_2", "move_forward", "move_left", "move_right", "move_back", "jump", "pause", "mute"]

func is_action_pressed(action: String) -> bool:
	return Input.is_action_pressed(action)

func get_move_axis() -> Vector2:
	return Input.get_vector("move_left", "move_right", "move_forward", "move_back")
