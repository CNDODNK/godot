class_name VysheSettings
extends Node
## Настройки с мгновенным применением и атомарным сохранением.

signal changed()

const SCHEMA_VERSION: int = 1
const SETTINGS_PATH: String = "user://vyshe_settings.json"
var values: Dictionary = {
	"schema": SCHEMA_VERSION, "difficulty": 1, "volume": 62, "sensitivity": 100,
	"crt": true, "wobble": true, "environment": 2, "muted": false,
	"music": true, "reverb": true, "buffer": "max", "resolution": 320, "shadows": true
}

func _ready() -> void:
	load_settings()

func apply_patch(patch: Dictionary) -> void:
	for key: String in patch:
		if values.has(key): values[key] = patch[key]
	changed.emit()
	EventBus.settings_applied.emit()

func save_settings() -> bool:
	var temp_path: String = SETTINGS_PATH + ".tmp"
	var file: FileAccess = FileAccess.open(temp_path, FileAccess.WRITE)
	if file == null: return false
	file.store_string(JSON.stringify(values))
	file.close()
	DirAccess.remove_absolute(SETTINGS_PATH)
	return DirAccess.rename_absolute(temp_path, SETTINGS_PATH) == OK

func load_settings() -> void:
	if not FileAccess.file_exists(SETTINGS_PATH): return
	var file: FileAccess = FileAccess.open(SETTINGS_PATH, FileAccess.READ)
	if file == null: return
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if parsed is Dictionary: apply_patch(parsed)
