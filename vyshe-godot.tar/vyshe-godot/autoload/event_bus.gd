class_name VysheEventBus
extends Node
## Типизированная шина событий игры.

signal hook_attached(hook_index: int, world_position: Vector3)
signal hook_released(hook_index: int)
signal stamina_depleted()
signal altitude_changed(height_meters: float)
signal checkpoint_reached(checkpoint_id: int, height_meters: float)
signal player_fell(height_meters: float)
signal world_changed(world_id: String)
signal settings_applied()
signal game_state_changed(previous_state: int, next_state: int)
signal save_completed(slot: int)
signal boot_failed(reason: String)
