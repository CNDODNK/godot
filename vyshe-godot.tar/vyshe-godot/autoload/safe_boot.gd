class_name VysheSafeBoot
extends Node
## Минимальный boot-узел. Ошибки запуска передаются в EventBus.

func _ready() -> void:
	# GameController переводит состояние в PLAYING после сборки мира.
	return
