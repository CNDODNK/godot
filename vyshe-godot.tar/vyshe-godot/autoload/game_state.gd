class_name VysheGameState
extends Node
const EventBusService = preload("res://autoload/event_bus.gd")
var event_bus: Node = EventBusService.new()
## Валидирует переходы основного конечного автомата.

enum State { BOOT, SPLASH, MENU, CATALOG, LOADING, PLAYING, PAUSED, FAILED, RESULTS }

const TRANSITIONS: Dictionary = {
	State.BOOT: [State.SPLASH, State.FAILED],
	State.SPLASH: [State.MENU, State.FAILED],
	State.MENU: [State.CATALOG, State.LOADING, State.PLAYING, State.FAILED],
	State.CATALOG: [State.MENU, State.LOADING],
	State.LOADING: [State.PLAYING, State.MENU, State.FAILED],
	State.PLAYING: [State.PAUSED, State.FAILED, State.RESULTS, State.MENU],
	State.PAUSED: [State.PLAYING, State.FAILED, State.MENU],
	State.FAILED: [State.PLAYING, State.MENU, State.RESULTS],
	State.RESULTS: [State.MENU, State.LOADING]
}

var current: State = State.BOOT

func transition(next_state: State) -> bool:
	var allowed: Array = TRANSITIONS.get(current, [])
	if not allowed.has(next_state):
		push_warning("Недопустимый переход GameState: %s -> %s" % [State.keys()[current], State.keys()[next_state]])
		return false
	var previous: State = current
	current = next_state
	event_bus.game_state_changed.emit(previous, current)
	return true
