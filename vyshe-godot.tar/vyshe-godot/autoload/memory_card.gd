class_name VysheMemoryCard
extends Node
## Версионируемые слоты сохранений с контрольной суммой и резервной копией.

const SCHEMA_VERSION: int = 1
const SLOT_COUNT: int = 3
const SAVE_PATH: String = "user://vyshe_memory_card.json"
const BACKUP_PATH: String = "user://vyshe_memory_card.bak"

func save_slot(slot: int, payload: Dictionary) -> bool:
	if slot < 0 or slot >= SLOT_COUNT: return false
	var card: Dictionary = load_card()
	var body: Dictionary = {"schema": SCHEMA_VERSION, "slot": slot, "payload": payload}
	body["checksum"] = _checksum(body)
	card["slots"][str(slot)] = body
	return _write_card(card)

func load_slot(slot: int) -> Dictionary:
	var card: Dictionary = load_card()
	var body: Dictionary = card.get("slots", {}).get(str(slot), {})
	if body.is_empty() or body.get("checksum", "") != _checksum(body): return {}
	return body.get("payload", {})

func load_card() -> Dictionary:
	if not FileAccess.file_exists(SAVE_PATH): return {"schema": SCHEMA_VERSION, "slots": {}}
	var file: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.READ)
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if parsed is Dictionary and parsed.get("schema", 0) == SCHEMA_VERSION: return parsed
	return {"schema": SCHEMA_VERSION, "slots": {}}

func _checksum(body: Dictionary) -> String:
	var copy: Dictionary = body.duplicate(true)
	copy.erase("checksum")
	return "%s" % hash(JSON.stringify(copy))

func _write_card(card: Dictionary) -> bool:
	if FileAccess.file_exists(SAVE_PATH): DirAccess.copy_absolute(SAVE_PATH, BACKUP_PATH)
	var file: FileAccess = FileAccess.open(SAVE_PATH + ".tmp", FileAccess.WRITE)
	if file == null: return false
	file.store_string(JSON.stringify(card)); file.close()
	DirAccess.remove_absolute(SAVE_PATH)
	return DirAccess.rename_absolute(SAVE_PATH + ".tmp", SAVE_PATH) == OK
