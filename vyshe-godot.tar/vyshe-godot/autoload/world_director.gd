class_name VysheWorldDirector
extends Node
## Управляет seed и переходами страт, генератор подключается на следующих фазах.

var run_seed: int = 0
var current_world_id: String = "vyshe"
var current_height: float = -300.0

func start_run(seed_value: int) -> void:
	run_seed = seed_value
	current_height = -300.0
	EventBus.world_changed.emit(current_world_id)
