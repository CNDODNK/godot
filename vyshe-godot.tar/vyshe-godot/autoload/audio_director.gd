class_name VysheAudioDirector
extends Node
signal settings_applied
const BUS_NAMES: Array[String] = ["Master", "Music", "SFX", "Ambient"]
var bus_ids: Dictionary = {}
var muted: bool = false
var volume: float = 0.62
var buffer_mode: String = "max"
var echo_level: String = "МАЛО"
func _ready() -> void:
	for index: int in range(BUS_NAMES.size()):
		var name: String = BUS_NAMES[index]
		var bus: int = AudioServer.get_bus_index(name)
		if bus < 0:
			var insert_at: int = AudioServer.get_bus_count()
			AudioServer.add_bus(insert_at)
			bus = AudioServer.get_bus_count() - 1
			AudioServer.set_bus_name(bus, name)
		bus_ids[name] = bus
	apply_settings()
func apply_settings() -> void:
	muted = bool(Settings.values.get("muted", false)); volume = float(Settings.values.get("volume", 62)) / 100.0
	buffer_mode = str(Settings.values.get("buffer", "max")); echo_level = str(Settings.values.get("echo", "МАЛО"))
	AudioServer.set_bus_mute(bus_ids.get("Master", 0), muted)
	AudioServer.set_bus_volume_db(bus_ids.get("Master", 0), linear_to_db(maxf(volume, 0.001)))
	settings_applied.emit()
	EventBus.settings_applied.emit()
func set_muted(value: bool) -> void:
	Settings.apply_patch({"muted": value}); apply_settings()
func set_volume(value: float) -> void:
	Settings.apply_patch({"volume": clampi(roundi(value * 100.0), 0, 100)}); apply_settings()
func set_buffer_mode(mode: String) -> void:
	if ["max", "big", "normal"].has(mode): Settings.apply_patch({"buffer": mode}); apply_settings()
func set_echo(level: String) -> void:
	if ["ВЫКЛ", "МАЛО", "СРЕДНЕ", "МНОГО"].has(level): Settings.apply_patch({"echo": level}); apply_settings()
func play_sfx(name: String, position: Vector3 = Vector3.ZERO) -> void:
	var player: AudioStreamPlayer3D = AudioStreamPlayer3D.new()
	player.name = "SFX_" + name
	player.position = position
	player.bus = "SFX"
	add_child(player)
	player.finished.connect(player.queue_free)
