class_name VysheTelemetry
extends Node
## Счётчики производительности и попытки.

var frame_count: int = 0
var fps: float = 0.0
var max_height: float = -300.0
var attempts: int = 0

func _process(delta: float) -> void:
	frame_count += 1
	fps = 1.0 / max(delta, 0.0001)
