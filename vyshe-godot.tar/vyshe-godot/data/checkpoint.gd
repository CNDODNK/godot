class_name VysheCheckpoint
extends Resource
@export var checkpoint_id: int = 0
@export var height_meters: float = -300.0
@export var world_seed: int = 0
@export var section_index: int = 0
