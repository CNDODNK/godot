class_name VysheGraphicsPreset
extends Resource
## Настраиваемый профиль PS1-пайплайна.

@export_enum("PS1 Pure", "PS1 Enhanced", "Modern Retro") var preset_name: String = "PS1 Enhanced"
@export var internal_size: Vector2i = Vector2i(320, 240)
@export_range(0.0, 1.0, 0.01) var vertex_snap_strength: float = 1.0
@export_range(0.0, 1.0, 0.01) var dither_strength: float = 1.0
@export_range(0.0, 1.0, 0.01) var crt_strength: float = 0.75
@export_range(0.0, 1.0, 0.01) var fog_strength: float = 0.55
@export var shadows_enabled: bool = false
@export var particles_enabled: bool = false
@export var volumetric_light_enabled: bool = false
@export var bloom_enabled: bool = false

static func pure() -> Resource:
	var profile: VysheGraphicsPreset = new()
	profile.preset_name = "PS1 Pure"
	profile.internal_size = Vector2i(320, 240)
	profile.vertex_snap_strength = 1.0
	profile.dither_strength = 1.0
	profile.crt_strength = 1.0
	profile.fog_strength = 0.7
	return profile

static func enhanced() -> Resource:
	var profile: VysheGraphicsPreset = new()
	profile.preset_name = "PS1 Enhanced"
	profile.internal_size = Vector2i(640, 480)
	profile.vertex_snap_strength = 0.72
	profile.dither_strength = 0.7
	profile.crt_strength = 0.55
	profile.fog_strength = 0.45
	profile.shadows_enabled = true
	profile.particles_enabled = true
	profile.volumetric_light_enabled = true
	profile.bloom_enabled = true
	return profile

static func modern_retro() -> Resource:
	var profile: VysheGraphicsPreset = new()
	profile.preset_name = "Modern Retro"
	profile.internal_size = Vector2i(960, 720)
	profile.vertex_snap_strength = 0.28
	profile.dither_strength = 0.3
	profile.crt_strength = 0.25
	profile.fog_strength = 0.3
	profile.shadows_enabled = true
	profile.particles_enabled = true
	profile.volumetric_light_enabled = true
	profile.bloom_enabled = true
	return profile
