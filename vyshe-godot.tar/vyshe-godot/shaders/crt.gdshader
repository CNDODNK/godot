shader_type canvas_item;

uniform sampler2D screen_texture : hint_screen_texture, filter_nearest;
uniform float strength : hint_range(0.0, 1.0) = 1.0;

void fragment() {
	vec2 centered = UV * 2.0 - 1.0;
	vec2 curved = centered * (1.0 + 0.042 * dot(centered, centered) * strength);
	vec2 uv = curved * 0.5 + 0.5;
	vec3 color = texture(screen_texture, uv).rgb;
	float lines = 0.92 + 0.08 * sin(UV.y * 480.0 * 3.14159);
	COLOR = vec4(color * lines, 1.0);
}
