shader_type spatial;
render_mode blend_mix, depth_prepass_alpha, cull_disabled;

uniform vec4 water_color : source_color = vec4(0.04, 0.26, 0.34, 0.76);
uniform sampler2D opaque_screen : hint_screen_texture, filter_nearest, repeat_disable;
uniform float ripple_strength : hint_range(0.0, 0.12) = 0.012;
uniform float reflection_strength : hint_range(0.0, 1.0) = 0.55;

void fragment() {
	vec2 wave = vec2(sin(UV.y * 48.0 + TIME * 2.0), cos(UV.x * 39.0 - TIME * 1.4));
	float fresnel = pow(1.0 - abs(dot(normalize(NORMAL), normalize(VIEW))), 3.0);
	vec2 reflection_uv = clamp(SCREEN_UV + vec2(wave.x * ripple_strength, -0.065 + wave.y * ripple_strength), vec2(0.0), vec2(1.0));
	vec3 reflected = texture(opaque_screen, reflection_uv).rgb;
	ALBEDO = water_color.rgb;
	ROUGHNESS = 0.25;
	EMISSION = reflected * reflection_strength * (0.22 + fresnel) + water_color.rgb * (0.08 + 0.06 * wave.x);
	ALPHA = water_color.a;
}
