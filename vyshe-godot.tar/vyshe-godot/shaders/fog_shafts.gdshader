shader_type spatial;
render_mode unshaded, blend_add, cull_back, depth_draw_never;

uniform vec4 shaft_color : source_color = vec4(0.85, 0.65, 0.32, 0.22);
uniform float pulse = 0.0;

void fragment() {
	float edge = pow(1.0 - abs(dot(normalize(NORMAL), normalize(VIEW))), 1.7);
	float fade = smoothstep(0.0, 0.16, UV.y) * (1.0 - smoothstep(0.67, 1.0, UV.y));
	ALBEDO = shaft_color.rgb;
	ALPHA = shaft_color.a * edge * fade * (0.9 + sin(TIME * 1.7 + pulse) * 0.1);
}
