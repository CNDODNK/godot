shader_type spatial;
render_mode vertex_lighting, specular_disabled, cull_back;

uniform sampler2D albedo_texture : source_color, filter_nearest, repeat_enable;
uniform vec4 albedo_color : source_color = vec4(1.0);
uniform float vertex_snap_strength : hint_range(0.0, 1.0) = 1.0;
uniform vec2 snap_resolution = vec2(320.0, 240.0);
uniform float affine_strength : hint_range(0.0, 1.0) = 1.0;
uniform float fog_amount : hint_range(0.0, 1.0) = 0.5;
uniform vec2 fog_range = vec2(5.0, 24.0);
uniform vec3 fog_color : source_color = vec3(0.11, 0.16, 0.23);
varying vec3 affine_uv_depth;

void vertex() {
	vec4 clip_position = PROJECTION_MATRIX * MODELVIEW_MATRIX * vec4(VERTEX, 1.0);
	float depth = max(clip_position.w, 0.0001);
	affine_uv_depth = vec3(UV * depth, depth);
	if (clip_position.w > 0.0001) {
		vec2 pixel = clip_position.xy / depth * snap_resolution;
		vec2 snapped = floor(pixel + vec2(0.5)) * depth / snap_resolution;
		clip_position.xy = mix(clip_position.xy, snapped, vertex_snap_strength);
	}
	POSITION = clip_position;
}

void fragment() {
	vec2 affine_uv = affine_uv_depth.xy / max(affine_uv_depth.z, 0.0001);
	vec2 sampled_uv = mix(UV, affine_uv, affine_strength);
	ALBEDO = texture(albedo_texture, sampled_uv * 2.0).rgb * albedo_color.rgb;
	float haze = smoothstep(fog_range.x, fog_range.y, -VERTEX.z) * fog_amount;
	FOG = vec4(fog_color, haze);
}
