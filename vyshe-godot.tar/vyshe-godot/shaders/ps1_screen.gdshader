shader_type canvas_item;

uniform sampler2D screen_texture : hint_screen_texture, repeat_disable, filter_nearest;
uniform float crt_strength : hint_range(0.0, 1.0) = 0.75;
uniform float dither_strength : hint_range(0.0, 1.0) = 0.8;
uniform float jitter_strength : hint_range(0.0, 1.0) = 0.25;
uniform vec2 internal_resolution = vec2(320.0, 240.0);

float bayer4(vec2 pixel) {
	ivec2 p = ivec2(mod(floor(pixel), 4.0));
	int index = p.x + p.y * 4;
	float values[16] = float[16](0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0, 3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0);
	return values[index] / 16.0;
}

void fragment() {
	vec2 centered = UV * 2.0 - 1.0;
	vec2 curved = centered * (1.0 + 0.042 * dot(centered, centered) * crt_strength);
	vec2 uv = curved * 0.5 + 0.5;
	vec2 jitter = vec2(sin(TIME * 47.0 + UV.y * 90.0), cos(TIME * 31.0)) * jitter_strength / internal_resolution;
	vec3 color = texture(screen_texture, clamp(uv + jitter, vec2(0.0), vec2(1.0))).rgb;
	vec2 pixel = floor(UV * internal_resolution);
	float dither = bayer4(pixel);
	color += (dither - 0.5) * dither_strength / 31.0;
	color = floor(clamp(color, 0.0, 1.0) * 31.0 + 0.5) / 31.0;
	float scanline = 1.0 - 0.22 * crt_strength * step(0.55, fract(FRAGCOORD.y * 0.5));
	float vignette = 1.0 - 0.22 * crt_strength * smoothstep(0.35, 1.0, length(centered));
	COLOR = vec4(color * scanline * vignette, 1.0);
}
