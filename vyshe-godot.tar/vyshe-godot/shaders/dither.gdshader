shader_type spatial;
render_mode unshaded;

uniform vec4 base_color : source_color = vec4(0.4, 0.3, 0.2, 1.0);
uniform float dither_strength : hint_range(0.0, 1.0) = 0.8;

void fragment() {
	float bayer = mod(floor(FRAGCOORD.x) + floor(FRAGCOORD.y) * 2.0, 4.0) / 4.0;
	vec3 color = base_color.rgb + (bayer - 0.5) * dither_strength / 31.0;
	ALBEDO = floor(clamp(color, 0.0, 1.0) * 31.0 + 0.5) / 31.0;
}
