shader_type canvas_item;
uniform vec3 shadow_tint : source_color = vec3(0.08, 0.12, 0.20);
uniform vec3 highlight_tint : source_color = vec3(1.0, 0.72, 0.42);
uniform float grade_strength : hint_range(0.0, 1.0) = 0.35;
void fragment() { vec3 color = texture(TEXTURE, UV).rgb; float luma = dot(color, vec3(0.299, 0.587, 0.114)); vec3 tint = mix(shadow_tint, highlight_tint, luma); COLOR = vec4(mix(color, color * tint * 1.55, grade_strength), 1.0); }
