shader_type canvas_item;

uniform float dither_strength : hint_range(0.0, 1.0) = 0.7;
uniform float crt_strength : hint_range(0.0, 1.0) = 0.55;
uniform float scanline_strength : hint_range(0.0, 1.0) = 0.35;
uniform float curvature : hint_range(0.0, 0.08) = 0.042;
uniform vec2 internal_resolution = vec2(640.0, 480.0);
uniform float vignette_strength : hint_range(0.0, 1.0) = 0.22;
uniform float chroma_pixels : hint_range(0.0, 4.0) = 0.8;
uniform float grille_strength : hint_range(0.0, 1.0) = 0.12;
uniform float noise_strength : hint_range(0.0, 0.1) = 0.013;
uniform float tail_strength : hint_range(0.0, 1.0) = 0.11;

uniform sampler2D grade_lut : filter_linear, repeat_disable;
uniform float grade_row = 0.166667;
uniform float grade_strength : hint_range(0.0, 1.0) = 0.0;

float bayer4(vec2 pixel) {
	ivec2 p = ivec2(mod(floor(pixel), 4.0));
	int index = p.x + p.y * 4;
	float values[16] = float[16](0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0, 3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0);
	return values[index] / 16.0;
}

void fragment() {
	vec2 centered = UV * 2.0 - 1.0;
	vec2 curved = centered * (1.0 + curvature * dot(centered, centered) * crt_strength);
	vec2 uv = curved * 0.5 + 0.5;
	vec3 color = texture(TEXTURE, clamp(uv, vec2(0.0), vec2(1.0))).rgb;
	if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
		color = vec3(0.015, 0.01, 0.025);
	}
	vec2 pixel = floor(uv * internal_resolution);
	if (crt_strength > 0.0 && all(equal(uv, clamp(uv, vec2(0.0), vec2(1.0))))) {
		vec2 fringe = vec2(chroma_pixels * crt_strength / internal_resolution.x, 0.0);
		color.r = texture(TEXTURE, clamp(uv + fringe, vec2(0.0), vec2(1.0))).r;
		color.b = texture(TEXTURE, clamp(uv - fringe, vec2(0.0), vec2(1.0))).b;
		vec3 trail = texture(TEXTURE, clamp(uv - vec2(2.0 / internal_resolution.x, 0.0), vec2(0.0), vec2(1.0))).rgb;
		color += max(trail - vec3(0.55), vec3(0.0)) * tail_strength * crt_strength;
	}
	if (grade_strength > 0.0) {
		vec3 sample_x = (clamp(color, 0.0, 1.0) * 255.0 + 0.5) / 256.0;
		vec3 graded = vec3(texture(grade_lut, vec2(sample_x.r, grade_row)).r,
			texture(grade_lut, vec2(sample_x.g, grade_row)).g,
			texture(grade_lut, vec2(sample_x.b, grade_row)).b);
		color = mix(color, graded, grade_strength);
	}
	float threshold = bayer4(pixel);
	color += (threshold - 0.5) * dither_strength / 31.0;
	color = floor(clamp(color, 0.0, 1.0) * 31.0 + 0.5) / 31.0;
	float screen_row = FRAGCOORD.y;
	float scanline = 1.0 - scanline_strength * crt_strength * step(0.55, fract(screen_row * 0.5));
	float flicker = 1.0 + 0.012 * sin(TIME * 118.0) * crt_strength;
	float vignette = 1.0 - vignette_strength * crt_strength * smoothstep(0.35, 1.0, length(centered));
	float channel = mod(floor(FRAGCOORD.x), 3.0);
	vec3 grille = vec3(1.0) - step(vec3(0.5), abs(vec3(0.0, 1.0, 2.0) - channel)) * grille_strength * crt_strength;
	float noise = fract(sin(dot(pixel + floor(TIME * 24.0), vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
	COLOR = vec4((color + noise * noise_strength * crt_strength) * grille * scanline * flicker * vignette, 1.0);
}
