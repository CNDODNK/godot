# ROADMAP

Фаза 2 — SubViewport, PS1/CRT shaders, graphics presets и test polygon.

Фаза 3 — CharacterBody3D, camera rig, stamina и один hook.

Фаза 4 — два hook, RopeSolver, swing, rest, failure и checkpoints.

Фаза 5 — strata generator, hatches, streaming, validators, catalog и world transitions.

Фаза 6 — полноценные UI-сцены, HUD, settings, Memory Card, CSV localization и SafeBoot.

Фаза 7 — AudioDirector, buses, reverb, delay, SFX и layered music.

Фаза 8 — enhanced lighting, particles, water, fog shafts и color grading.

Фаза 9 — performance pass, unit/smoke tests, docs и delivery report.
