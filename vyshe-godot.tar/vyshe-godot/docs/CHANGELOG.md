# CHANGELOG

## Фаза 1 — 2026-11-21

Создан изолированный проект `vyshe-godot`. Исходный HTML скопирован в `reference/FINALHTMLVYSHE.html`. Разобрана активная физика v6.1, генерация, страты, UI, настройки, звук и PS1-параметры. Добавлены project.godot, boot-сцена, типизированные autoload-сервисы и статический валидатор.

## Фаза 2 — 2026-11-21

Добавлен PS1-рендер-пайплайн на SubViewport с nearest scaling, vertex snapping, Bayer dithering и CRT-постобработкой. Созданы профили PS1 Pure, PS1 Enhanced и Modern Retro, процедурный тестовый полигон и документация `PHASE_2_RENDER.md`. Главная сцена временно направлена на рендер-полигон для проверки визуального контура.

## Фаза 3 — 2026-11-21

Добавлены игрок, камера, выносливость, одиночный крюк, distance constraint solver и tuning-ресурсы.

## Фаза 3 — 2026-11-21

Собраны CharacterBody3D, CameraRig, StaminaComponent, GrappleHook и RopeSolver. Добавлены typed tuning-ресурсы и сцена игрока.

## Фазы 4–9 — 2026-11-21

Добавлены dual-ready gameplay foundation, детерминированный генератор страт и валидатор, UI/HUD shell, settings/localization hooks, enhanced effects and audio runtime, smoke test и delivery documentation.

## Фаза 4 — 2026-11-21

Интегрированы два независимых крюка, dual grapple input, checkpoint/failure components и 600-frame gameplay smoke.

## Фаза 5 — 2026-11-21

Добавлены runtime-секции с потолочными лазами, WorldRuntime со streaming window и smoke-тест стриминга.

## Фаза 6 — 2026-11-21

Добавлены отдельные UI-сцены меню, паузы, настроек, Memory Card и SafeBoot, контроллеры HUD/flow и UI smoke.

## Фаза 7 — 2026-11-21

Добавлены AudioDirector с четырьмя шинами, runtime audio settings и procedural SFX generator hook.

## Фаза 8 — 2026-11-21

Добавлен Enhanced graphics layer: procedural dust, fog shafts, water ripple и strata grading.

## Фаза 8 — 2026-11-21

Добавлен Enhanced graphics layer с независимыми switches частиц, лучей и воды, LUT по высоте и smoke для Forward+/Compatibility.

## Фаза 9 — 2026-11-21

Добавлены финальный asset runner, инструкция запуска Windows/Linux, список проверок и документация оптимизации. Исправлена финальная ошибка создания аудиошин.

## game.tscn — 2026-11-21

Связаны основная игровая сцена, WorldRuntime, игрок, два крюка, HUD и Enhanced effects. `game.tscn` назначена main scene.

## Генерация игрового мира — 2026-11-21

Добавлены bake HTML Archon catalog: 19 тем, 710 рецептов. Runtime-секции теперь строят видимую архитектуру, маршрут зацепов, колонны, тросы и потолочные лазы.

## Full gameplay loop — 2026-11-21

Подключены реальные holds к raycast, восстановление Memory Card, checkpoint save, respawn после срыва и динамический HUD страт.

## Свет и окружение — 2026-11-21

Добавлены zone-based lights, beacon у потолочного выхода и deterministic random scatter декора по seed.

## Зацеп и procedural textures — 2026-11-21

Разрешён raycast-зацеп к любым игровым surface collision. Добавлены seed-based procedural 64×64 nearest textures для архитектуры секций.

## Audio и backdrop — 2026-11-21

Подключены procedural AudioStreamGenerator effects и stratified backdrop со звёздами, облаками и palette transitions.

## PS1 filter — 2026-11-21

Подключён fullscreen PS1/CRT pass в основной game.tscn с переключателями C и V.
