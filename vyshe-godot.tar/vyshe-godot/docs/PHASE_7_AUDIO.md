# Фаза 7 — аудио

AudioDirector создаёт и именует шины Master, Music, SFX и Ambient, применяет mute, volume, echo level и buffer mode через Settings. `tools/gen_sfx.gd` фиксирует процедурную генерацию SFX через AudioStreamGenerator без внешних бинарных ассетов. Дальнейшие звуковые банки могут подключаться по имени через `play_sfx`.
