# LEVEL DESIGN

Каждый LevelSection содержит seed, тему, высоту, стартовую платформу, каталог построек, holds, checkpoint и выход. Генерация детерминирована Mulberry32. Выход подземной секции всегда размещён в потолке. Декор получает collision-free placement и не может перекрывать hold route.

Новый мир добавляется через WorldDefinition Resource, список StrataDefinition и каталог визуальных тем. Код WorldDirector менять не требуется. Перед загрузкой секция проходит LevelValidator.
