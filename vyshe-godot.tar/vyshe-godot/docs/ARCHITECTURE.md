# ARCHITECTURE

Проект разделён на сервисы, компоненты игрока, ресурсные данные, сцены и валидаторы. Autoload-сервисы общаются типизированными сигналами EventBus. Геймплейные компоненты получают зависимости через ссылки на узлы и ресурсы. Строки UI будут вынесены в CSV-локализацию.

`GameState` отвечает за переходы Boot → Splash → Menu → Catalog → Loading → Playing ⇄ Paused → Failed → Results. `Settings` применяет патчи и пишет атомарный JSON. `MemoryCard` держит три слота, схему, checksum и backup. `WorldDirector` владеет seed и активной высотой. `AudioDirector`, `InputService`, `Telemetry` и `SafeBoot` отделяют системные функции от сцены.

Игрок будет CharacterBody3D с PlayerStateMachine, StaminaComponent, CameraRig и GrappleSystem. RopeSolver изменяет velocity/position только в physics loop. WorldDefinition, StrataDefinition и LevelSection будут Resource-классами. LevelValidator проверяет связность навигационного графа, потолочный лаз и свободные зоны декора.
