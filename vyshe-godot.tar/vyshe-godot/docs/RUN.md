# Как запустить VYSHE

## Windows

Откройте `Godot_v4.7.2-stable_mono_win64.exe`, выберите импорт существующего проекта и укажите папку `D:\VYSHE\vyshe-godot`. Откройте проект и нажмите Play. Стартовая сцена — `scenes/menu/main_menu.tscn`. Нажмите `НОВАЯ ИГРА`, чтобы загрузить `scenes/game/game.tscn`.

Для запуска из PowerShell:

```powershell
cd D:\VYSHE
.\Godot_v4.7.2-stable_mono_win64.exe --editor --path .\vyshe-godot
```

Для запуска без редактора:

```powershell
cd D:\VYSHE
.\Godot_v4.7.2-stable_mono_win64.exe --path .\vyshe-godot
```

## Linux

В терминале:

```bash
cd /path/to/VYSHE
chmod +x ./Godot_v4.7.2-stable_mono_linux_x86_64/Godot_v4.7.2-stable_mono_linux.x86_64
./Godot_v4.7.2-stable_mono_linux_x86_64/Godot_v4.7.2-stable_mono_linux.x86_64 --editor --path ./vyshe-godot
```

Без редактора:

```bash
./Godot_v4.7.2-stable_mono_linux_x86_64/Godot_v4.7.2-stable_mono_linux.x86_64 --path ./vyshe-godot
```

Mono-сборка Godot может требовать установленный .NET runtime. Для этого проекта используется GDScript, поэтому при наличии обычной non-Mono сборки предпочтительна она.

## Проверки

Из корня `vyshe-godot`:

```bash
godot --headless --path . --script tools/validate_static.gd
godot --headless --path . --script tests/run_final.gd
godot --headless --path . --script tests/run_gameplay_smoke.gd
godot --headless --path . --script tests/world_stream_smoke.gd
godot --headless --path . --script tests/ui_smoke.gd
godot --headless --path . --script tests/audio_smoke.gd
godot --headless --path . --script tests/enhanced_smoke.gd
```

Ожидаемые маркеры успеха: `STATIC_OK`, `FINAL_ASSET_CHECK_OK`, `GAMEPLAY_SMOKE_OK`, `WORLD_STREAM_OK`, `UI_SMOKE_OK`, `AUDIO_SMOKE_OK` и `ENHANCED_SMOKE_OK`.

## Управление полигоном

`1`, `2`, `3` переключают PS1 Pure, PS1 Enhanced и Modern Retro. `C` включает или выключает CRT. `V` включает или выключает vertex snapping. `B` меняет палитру страты. `F` запускает тестовые искры. `P`, `L`, `O` переключают частицы, лучи и воду.

## Игрок

В игровой сцене используются W/A/S/D, Space, мышь, ЛКМ и ПКМ для двух крюков, Q/E для отпускания, ESC для паузы и M для звука.
