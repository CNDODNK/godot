# Фаза 8 — графический апгрейд

Добавлены procedural GPUParticles3D dust, fog shaft meshes, water ripple shader и strata grade shader. `VysheEnhancedEffects` управляет частицами, лучами и водой через graphics profile. Все эффекты имеют runtime visibility switches и работают без внешних бинарных ассетов.
