# Фаза 3 — игрок и одиночный крюк

`Player` использует CharacterBody3D, отдельные CameraRig, StaminaComponent и GrappleHook. Силы движения, прыжка и крюка хранятся в `data/movement.tres` и `data/hook_tuning.tres`. Крюк стреляет physics raycast, промах отпускает текущий якорь. RopeSolver ограничивает дистанцию 2.4 м тремя итерациями и удаляет outward velocity.

Активные значения v6.1 сохранены. Управление подключается через InputService и InputMap. Сцена проверена headless Godot 4.7.2.
