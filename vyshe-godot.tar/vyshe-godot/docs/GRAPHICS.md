# GRAPHICS

PS1 Pure использует SubViewport, nearest scaling, отсутствие AA, vertex snapping, affine-like UV режим, 15/16-bit color quantization, Bayer dithering, глубинный fog и низкополигональные меши. CRT-пост включает кривизну, scanlines, aperture grille, chromatic aberration, noise, bloom tail и vignette. Все параметры должны иметь дешёвый fallback.

PS1 Enhanced сохраняет low-res буфер и добавляет стилизованные тени, фонарь, стратифицированный цвет, GPU particles и fog shafts. Modern Retro добавляет ограниченный bloom, color grading LUT и SSAO при доступном Forward+.

В HTML были зафиксированы snap 213×120, Bayer 4×4, 31 цветовой уровень, curve 0.042 и flicker 118 Гц. Эти значения входят в основу шейдерных ресурсов следующих фаз.
