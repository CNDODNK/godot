# Фаза 2 — PS1-рендер-пайплайн

Пайплайн использует `SubViewport` с внутренним разрешением профиля и `SubViewportContainer` для растяжения в окно. Текстуры и постобработка работают с nearest filtering. `ps1_surface.gdshader` выполняет clip-space vertex snapping с uniform-силой, а `ps1_post.gdshader` применяет Bayer 4×4, 15/16-bit quantization, CRT curvature, scanlines, flicker и vignette.

Профили `PS1 Pure`, `PS1 Enhanced` и `Modern Retro` описаны `VysheGraphicsPreset` и тремя `.tres` ресурсами. Полигон строится процедурно и содержит платформу, шесть низкополигональных колонн, пять подвесных колец и цветное освещение. Внешние ассеты для сцены не нужны.

`VyshePs1RenderPipeline` получает ссылки на viewport, поверхность и post material, меняет профиль в рантайме и обновляет время CRT. Следующая фаза подключит реальные UI-переключатели и GPU-эффекты Enhanced.
