# TEST_REPORT

## Фаза 1 — 2026-11-21

Копирование источника. PASS. `reference/FINALHTMLVYSHE.html` создан внутри проекта, размер копии 548081 байт.

Структура каталогов. PASS. Созданы требуемые каталоги `docs`, `autoload`, `src`, `scenes`, `shaders`, `assets`, `data`, `tests`, `tools`.

Godot CLI. NOT RUN. В окружении не обнаружен доступный бинарник Godot CLI. Проект и `tools/validate_static.gd` подготовлены для запуска при наличии Godot 4.x.

Headless smoke. NOT RUN. Фаза 1 ещё не содержит игровой рантайм smoke-сценария.

Статический валидатор. PENDING RUN. Запускать из корня проекта командой `godot --headless --path . --script tools/validate_static.gd`.

Проверка JavaScript. PASS. Из трёх script-блоков HTML извлечено 521889 байт inline JavaScript, `node --check` не обнаружил синтаксических ошибок.

Godot binary discovery. FOUND. `D:\VYSHE\Godot_v4.7.2-stable_mono_win64.exe` присутствует в основной папке. В текущей Linux-песочнице Windows binary не запускается, Wine отсутствует, поэтому Godot static validator остаётся NOT RUN здесь.

Документация и autoload-регистрация. PASS. Проверены ключевые параметры спецификации и девять обязательных autoload entries.

Linux Godot CLI. PASS. Найден и запущен `Godot_v4.7.2-stable_mono_linux.x86_64`. Команда `godot --headless --path . --script tools/validate_static.gd` завершилась с `STATIC_OK required_files=5`.

Godot editor parse attempt. BLOCKED BY ENVIRONMENT. Запуск `--headless --editor --quit` использовал Mono-сборку, но в sandbox отсутствует `dotnet`/hostfxr и нет display. После диагностических сообщений редактор завершился с SIGSEGV. Headless static validator при этом успешно отработал. Полный runtime smoke-test ещё не запускался.

## Фаза 2 — 2026-11-21

Ресурсы графических профилей. PASS by static inspection. Проверены три `.tres` ресурса и `VysheGraphicsPreset` с внутренними размерами 320×240, 640×480 и 960×720.

Shader inventory. PASS by static inspection. Созданы и связаны `ps1_surface.gdshader`, `ps1_post.gdshader`, `dither.gdshader` и `crt.gdshader`. Проверены uniform-параметры snapping, Bayer dithering, CRT curvature, scanlines и fog.

Render polygon. PASS by static inspection. Сцена `scenes/game/render_polygon.tscn` содержит SubViewport, SubViewportContainer, процедурную геометрию, камеру, окружение и post material. Бинарный runtime scene launch в текущей sandbox не подтверждён, так как доступна Mono-сборка без dotnet/hostfxr.

Фаза 2 runtime scene load. PASS WITH ENVIRONMENT WARNINGS. Linux Godot 4.7.2 загрузил `res://scenes/game/render_polygon.tscn` в headless-режиме и завершил команду с кодом 0. В логе не осталось ошибок GDScript или shader compilation. Сообщения Mono про отсутствующий dotnet/hostfxr и display относятся к сборке/окружению.

Фаза 2 исправления после первого запуска. PASS. Устранены ошибки незагруженного типа профиля, несовместимых shader identifiers и `return` в fragment processor. Проверка повторена.

## Фаза 3 — 2026-11-21

Сцена игрока. PASS. `scenes/player/player.tscn` загрузилась headless Godot 4.7.2 без GDScript parse errors. Mono/display diagnostics относятся к текущей среде.

Статический валидатор. PASS. Результат `STATIC_OK required_files=5` сохранён в `tests/static_validate_phase3.log`.

## Фазы 4–9 — 2026-11-21

Добавлены генератор, валидатор, UI, audio/effects hooks и smoke-test. Полный runtime smoke-test запускается после проверки проекта командой `godot --headless --path . --script tests/run_smoke.gd`. Компоненты покрывают архитектурный контур, полноценные экраны и production-ассеты остаются roadmap.

UI smoke. PASS. `tests/ui_smoke.gd` загрузил 5 UI-сцен без GDScript compile errors: `UI_SMOKE_OK screens=5`.

Детерминизм генератора. PASS. `tests/run_smoke.gd` подтвердил одинаковый результат для seed 12345 и 12 секций: `SMOKE_OK sections=12`.

Ограничение итогового контура. Фазы 4–9 представлены рабочими архитектурными компонентами и smoke/static checks, но не полным production-complete содержанием всех UI-экранов, аудиобанков, streaming scenes и 600-frame gameplay path. Это отражено в `docs/PHASES_4_9.md`.

## Фаза 4 — 2026-11-21

Dual hook scene load. PASS. `scenes/player/player.tscn` загрузилась headless без GDScript parse errors.

Gameplay smoke. PASS. `tests/run_gameplay_smoke.gd` завершён с `GAMEPLAY_SMOKE_OK frames=600 checkpoint=-264.80`.

Static validation. PASS. `STATIC_OK required_files=5`.

## Фаза 5 — 2026-11-21

World streaming smoke. PASS. `tests/world_stream_smoke.gd` завершён с `WORLD_STREAM_OK loaded=6 sections=32`. Проверены загрузка окна соседних секций, переход к секции 8 и выгрузка старых секций.

Static validation. PASS. `STATIC_OK required_files=5`.

## Фаза 7 — 2026-11-21

Audio smoke. PASS. `tests/audio_smoke.gd` подтвердил четыре шины: `AUDIO_SMOKE_OK buses=4`. SFX generator завершён с `SFX_GENERATOR_OK`. Static validation также PASS.

## Фаза 8 — 2026-11-21

Добавлены procedural dust, fog shafts, water ripple и strata grading shaders.

## Фаза 8 — 2026-11-21

Enhanced smoke. PASS on Forward+ and Compatibility. `tests/enhanced_smoke.gd` подтвердил три профиля, LUT 256×3, pool из 4 искровых эмиттеров, dispatch от hook_attached, отключение Pure и независимые switches: `ENHANCED_SMOKE_OK profiles=3 lut=256x3 spark_pool=4`.

Static validation. PASS. `STATIC_OK required_files=5`. Исправлена ошибка создания AudioDirector buses при загрузке enhanced scene.

## Фаза 9 — 2026-11-21

Final asset check. PASS. `tests/run_final.gd` подтвердил 10 ключевых сцен, ресурсов и шейдеров: `FINAL_ASSET_CHECK_OK files=10`.

Static validation. PASS. `STATIC_OK required_files=5`. AudioDirector bus creation corrected and final check повторён без project errors.

Run guide. PASS. `docs/RUN.md` содержит Windows/Linux запуск, headless checks, управление полигоном и управление игроком.

Launch documentation. PASS by file inspection. Добавлены `docs/RUN.md` и `docs/OPTIMIZATION.md`.

## game.tscn integration — 2026-11-21

Game scene smoke. PASS. `tests/game_scene_smoke.gd` подтверждает создание игрока, HUD и 32 секций: `GAME_SCENE_SMOKE_OK player=1 hud=1 sections=32`.

Mouse and hook visibility fix. PASS. Camera captures mouse on ready, ESC releases it, click recaptures it. GrappleSystem now creates visible cyan/magenta procedural hook models for K1/K2 and updates attached positions.

Gameplay spawn fix. PASS. `tests/game_start_smoke.gd` confirms the main scene starts at `altitude=-299.1` with `sections=32`, on the DНИЩЕ level rather than the render test polygon.

Godot headless сообщает 3 leaked ObjectDB instances при немедленном завершении smoke-сцены. Это относится к тестовому завершению до полного deferred cleanup, а не к ошибке загрузки game.tscn. В Windows runtime перед выходом сцена должна закрываться обычным tree lifecycle.

## Генерация мира — 2026-11-21

Предыдущая runtime-секция была только плоской тестовой плитой. Исправлено. `tools/bake_archon.cjs` извлекает из `reference/FINALHTMLVYSHE.html` 19 тем и 710 рецептов Archon в `data/archon_catalog.json`. `VysheSectionRuntime` теперь строит архитектурные детали из рецепта, процедурный маршрут платформ и holds, колонны, соединительные тросы, checkpoint и светящийся потолочный hatch.

Visual generation smoke. PASS. `GENERATION_VISUAL_OK nodes=180 route=5 hatch=1`.

Game start smoke. PASS. `GAME_START_OK altitude=-299.1 sections=32`.

## Full gameplay loop — 2026-11-21

Holds. PASS. Generated visual holds now have StaticBody3D collision and `grapple_hold` metadata. Player raycast accepts only these generated holds.

Gameplay loop smoke. PASS. `GAME_LOOP_OK respawn=1 save_service=1 holds=1` confirms scene startup, checkpoint/save service, fall respawn and real generated holds. Generation smoke remains `GENERATION_VISUAL_OK nodes=190 route=5 hatch=1`.

## Свет и random scatter — 2026-11-21

Добавлены детерминированные OmniLight3D по каждой секции, цвет которых зависит от зоны и accent palette. Добавлены random scatter rocks/posts/trim с seed-based placement, density 5–9 и зонами радиуса 4.2–8.0, по смыслу близкими HTML `placeEnvironment`.

Lighting/scatter smoke. PASS. `LIGHT_SCATTER_OK lights=5 scatter=7 deterministic=1`. Generation smoke: `GENERATION_VISUAL_OK nodes=204 route=5 hatch=1`. Full loop: `GAME_LOOP_OK respawn=1 save_service=1 holds=1`.

## Зацеп поверхностей и procedural textures — 2026-11-21

Hook targeting. PASS. Raycast теперь цепляется к любой физической поверхности игрового мира под прицелом, а промах по пустоте отпускает крюк. Специальные holds сохраняют отдельные метаданные rest.

Procedural textures. PASS. Добавлен `VysheProceduralSurface`, создающий seed-based 64×64 nearest textures с шумом, клеткой и трещинами. Runtime-секция назначает текстуру архитектурным материалам.

Smoke. PASS. `HOOK_TEXTURE_OK texture=64x64 surfaces=28`, `GAME_LOOP_OK respawn=1 save_service=1`, `STATIC_OK required_files=5`.

## Audio и backdrop — 2026-11-21

Procedural audio. PASS. `VysheProceduralAudio` создаёт пять AudioStreamGenerator players для step, hook, jump, checkpoint и fail, подключённых к SFX bus. Игровой controller triggers checkpoint и fail, player triggers jump.

Backdrop. PASS. `VysheBackdrop` создаёт MultiMesh звёзд, три облачных слоя и меняет палитру/видимость по высоте. Game loop smoke подтверждает `audio.players=5` и наличие stars layer.

Full loop remains PASS: `GAME_LOOP_OK respawn=1 save_service=1 holds=1`.

## Main menu and HUD — 2026-11-21

Проект на диске проверен. `D:\VYSHE\vyshe-godot\project.godot` и 311 файлов доступны. `main_scene` переключён на `scenes/menu/main_menu.tscn`. Главное меню загружается первым, `НОВАЯ ИГРА` создаёт `game.tscn`.

Smoke. PASS. `MENU_HUD_OK menu=1 new_game=1 hud=1`. HUD содержит Height, Stamina, Hook и Hint.

## PS1 filter in main game — 2026-11-21

Добавлен fullscreen PS1/CRT pass `shaders/ps1_screen.gdshader` поверх основной `game.tscn`. Он применяет nearest screen sampling, Bayer dithering, 31-level color quantization, scanlines, vignette, curvature и jitter. `C` отключает CRT/pass, `V` отключает jitter.

Smoke. PASS. `GAME_LOOP_OK respawn=1 save_service=1 holds=1`, `GAME_SCENE_SMOKE_OK player=1 hud=1 sections=32`, `STATIC_OK required_files=5`. Smoke подтверждает наличие PS1 overlay и material в основной сцене.
