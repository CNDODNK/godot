# DELIVERY

Фаза 1 завершена. Создан изолированный Godot-проект `vyshe-godot`, исходник сохранён в `reference/FINALHTMLVYSHE.html`, а спецификация поведения зафиксирована в `docs/SPEC_FROM_HTML.md`.

Перенесены в документацию активные числовые константы v6.1, формулы прыжка, тяги, маятника, тросового ограничения, stamina и отдыха, правила страт, потолочных лазов, чекпоинтов, рекорда, стриминга, UI-состояний, настроек, звука и PS1-постобработки. Различия Godot и решения записаны в `docs/DECISIONS.md`.

Создана базовая архитектура с типизированными autoload-сервисами EventBus, GameState, Settings, MemoryCard, AudioDirector, WorldDirector, InputService, Telemetry и SafeBoot. Проект использует 640×480 viewport и GL Compatibility как безопасный стартовый renderer. Строгая физика, сцены игрока, генератор, UI, шейдеры, звук и тестовый раннер входят в следующие фазы.

Запуск после установки Godot 4.x выполняется из корня `vyshe-godot` командой `godot --path .`. Статическая проверка выполняется командой `godot --headless --path . --script tools/validate_static.gd`.

Ограничение фазы. Godot CLI в текущем окружении не найден, поэтому фактический runtime smoke-test ещё не запускался. Это отражено в `docs/TEST_REPORT.md`.

Фазы 4–9 добавили детерминированный strata generator, level validator, UI shell, settings/localization hooks, enhanced effects/audio hooks и smoke test. Полный художественный контент и отдельные production-экраны требуют последующих итераций.

Фактическая финальная проверка. `tests/run_smoke.gd` завершён с `SMOKE_OK sections=12`. `tests/run_final.gd` завершён с `FINAL_ASSET_CHECK_OK files=10`. `tools/validate_static.gd` завершён с `STATIC_OK required_files=5`. Логи находятся в `tests/smoke_final.log`, `tests/final_final.log` и `tests/static_final.log`.

Инструкция запуска Windows/Linux находится в `docs/RUN.md`. Базовая сцена запуска — `scenes/game/render_polygon.tscn`. Для полного игрового прототипа игрок подключается отдельной сценой `scenes/player/player.tscn`.

Фаза 4 теперь содержит два независимых крюка в сцене игрока, отдельные hook input actions, checkpoint/failure components и headless smoke на 600 физических кадров. Сцена игрока и smoke проходят Godot 4.7.2.

Фаза 5 содержит `VysheWorldRuntime`, `VysheSectionRuntime`, потолочные hatch Area3D и streaming window. Smoke подтверждает 32 детерминированные секции и окно из 6 загруженных соседей.

Фаза 6 содержит отдельные сцены меню, паузы, настроек, Memory Card и SafeBoot, а также UI flow controller и HUD shell. UI smoke подтверждает загрузку пяти экранов.

Фаза 7 содержит AudioDirector с четырьмя шинами и runtime-настройками, а также procedural SFX generator hook. Audio smoke подтверждает создание аудиографа.

Фаза 8 содержит рабочий Enhanced layer с dust GPUParticles3D, pool искр, fog shafts, water reflection/ripple shader, altitude palette LUT, фонарём и независимыми switches. Smoke проходит на Forward+ и Compatibility.

Стартовая сцена теперь `scenes/menu/main_menu.tscn` и установлена в `project.godot` как `run/main_scene`. Кнопка `НОВАЯ ИГРА` создаёт `scenes/game/game.tscn`, которая запускает WorldRuntime, игрока, HUD, аудио, backdrop и PS1 overlay. Она создаёт WorldRuntime на 32 секции, стартовую площадку, CharacterBody3D игрока с двумя крюками, HUD и Enhanced effects. Game scene smoke подтверждает `player=1 hud=1 sections=32`.

Стартовая сцена теперь главное меню. Кнопка `НОВАЯ ИГРА` создаёт `game.tscn`, HUD содержит высоту, выносливость, статусы К1/К2, подсказку и прицел.

Исправлен захват мыши. Камера захватывает мышь при старте, ESC освобождает её, клик возвращает захват. `GrappleSystem` создаёт видимые процедурные модели К1 и К2 с циановым и пурпурным акцентами.

Игровой spawn перенесён на ДНИЩЕ. `game.tscn` стартует около -300 м, земля и WorldRuntime используют одну высотную систему, а `game_start_smoke.gd` подтверждает `altitude=-299.1 sections=32`.

Исправлен критический пробел генерации. Ранее game.tscn визуально содержала только плоские тестовые плиты. Теперь HTML-каталог Archon извлекается в `data/archon_catalog.json`, а runtime-секции используют эти рецепты для построек, маршрутов holds, колонн, тросов, checkpoint и потолочного hatch. Visual smoke подтверждает 180 узлов, 5 route points и hatch.

Подключён игровой цикл. Сгенерированные holds получили collision и принимаются raycast крюка. GameController восстанавливает seed/height/index из Memory Card, обновляет checkpoint, сохраняет слот, респаунит игрока после падения и передаёт актуальную страту в HUD. Smoke подтверждает `GAME_LOOP_OK respawn=1 save_service=1 holds=1`.

Исправлены свет и окружение. Каждая runtime-секция теперь получает 4–6 источников света с zone palette, включая beacon у выхода. Декор размещается детерминированно по seed, с разбросом радиуса и типами rock/post/trim. Smoke подтверждает `lights=5 scatter=7 deterministic=1`.

Исправлен hook targeting. Крюк теперь принимает любую физическую игровую поверхность под прицелом, а не только holds. Добавлены seed-based процедурные 64×64 nearest textures для runtime-архитектуры, с шумом, клеточным паттерном и трещинами. Smoke подтверждает 28 поверхностей и текстуру 64×64.

Добавлены реальные procedural sounds: пять AudioStreamGenerator-источников для шагов, крюка, прыжка, checkpoint и срыва. Добавлен VysheBackdrop с MultiMesh звёзд, облачными слоями, палитрами подземелья/поверхности/космоса и переходом по высоте. Game loop smoke подтверждает наличие audio players и backdrop.

PS1-фильтр возвращён в основную игру. `game.tscn` содержит fullscreen `PS1Overlay` с `ps1_screen.gdshader`, который применяет low-res nearest-like sampling, Bayer dithering, color quantization, CRT scanlines, curvature, vignette и jitter. `C` переключает фильтр, `V` переключает jitter.
