extends SceneTree
func _init() -> void:
	var scene: PackedScene = load("res://scenes/levels/section_runtime.tscn")
	var section: Node = scene.instantiate(); root.add_child(section)
	section.build({"seed": 4321, "origin": -300.0, "height": 8.0, "exit": -292.0, "index": 0, "zone_id": "bottom"})
	await process_frame
	assert(section.surface_texture != null)
	assert(section.surface_texture.get_size() == Vector2(64, 64))
	assert(section.surface_material.albedo_texture != null)
	var body_count: int = 0
	for child: Node in section.get_children():
		if child is StaticBody3D: body_count += 1
	assert(body_count >= 10)
	print("HOOK_TEXTURE_OK texture=64x64 surfaces=%d" % body_count)
	quit(0)
