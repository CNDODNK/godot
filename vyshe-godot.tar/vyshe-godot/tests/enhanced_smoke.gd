extends SceneTree

const POLYGON: PackedScene = preload("res://scenes/game/render_polygon.tscn")
const Pipeline = preload("res://src/core/ps1_render_pipeline.gd")

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var polygon: Pipeline = POLYGON.instantiate() as Pipeline
	root.add_child(polygon)
	await process_frame
	var effects: Node3D = polygon.effects
	if not _check(effects.dust.emitting and effects.shafts.visible and effects.water.visible, "Enhanced effects default"):
		return
	if not _check(effects.sparks.size() == 4 and effects.grade_lut.get_size() == Vector2(256, 3), "Particle pool and LUT"):
		return
	polygon.select_preview_stratum(2)
	if not _check(is_equal_approx(float(polygon.post_material.get_shader_parameter("grade_row")), 2.5 / 3.0), "Star palette reaches post shader"):
		return
	var bus: Node = root.get_node("EventBus")
	var point: Vector3 = Vector3(1, 2, -2)
	bus.emit_signal(&"hook_attached", 0, point)
	if not _check(effects.next_spark == 1 and effects.sparks[0].global_position.is_equal_approx(point), "Hook dispatch reaches spark pool"):
		return
	polygon.select_profile(0)
	if not _check(not effects.dust.emitting and not effects.shafts.visible and not effects.water.visible and not effects.lamp.visible, "Pure disables Enhanced effects"):
		return
	polygon.particles_allowed = false
	polygon.water_allowed = false
	polygon.select_profile(2)
	if not _check(not effects.dust.emitting and not effects.water.visible and effects.shafts.visible, "Independent overrides"):
		return
	for bus_name: String in ["Master", "Music", "SFX", "Ambient"]:
		if not _check(AudioServer.get_bus_index(bus_name) >= 0, "Named audio bus " + bus_name):
			return
	print("ENHANCED_SMOKE_OK profiles=3 lut=256x3 spark_pool=4")
	quit()

func _check(condition: bool, message: String) -> bool:
	if not condition:
		push_error(message)
		quit(1)
	return condition
