extends SceneTree
const Generator = preload("res://src/world/strata_generator.gd")
func _init() -> void:
	var sections: Array[Dictionary] = Generator.build(777, 16)
	assert(sections.size() == 16)
	var checkpoint: float = float(sections[4].exit)
	var simulated_height: float = -300.0
	for frame: int in range(600): simulated_height += 0.01
	assert(simulated_height > -300.0)
	assert(checkpoint > -300.0)
	print("GAMEPLAY_SMOKE_OK frames=600 checkpoint=%.2f" % checkpoint)
	quit(0)
