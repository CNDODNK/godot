extends SceneTree
func _init() -> void:
	var menu_scene: PackedScene = load("res://scenes/menu/main_menu.tscn")
	assert(menu_scene != null)
	var menu: Node = menu_scene.instantiate()
	root.add_child(menu)
	await process_frame
	assert(menu.get_node("Menu/Panel/Actions/NewGame") != null)
	assert(menu.get_node("Menu/Panel/Title").text == "ВЫШЕ")
	assert(menu.settings != null)
	menu._on_menu_action(&"Settings")
	assert(menu.settings.visible)
	menu._close_settings()
	assert(menu.get_node("Menu").visible)
	var game_scene: PackedScene = load("res://scenes/game/game.tscn")
	var game: Node = game_scene.instantiate()
	root.add_child(game)
	await process_frame
	assert(game.get_node("HUD/Height") != null)
	assert(game.get_node("HUD/Stamina") != null)
	assert(game.get_node("HUD/Hook") != null)
	assert(game.get_node("HUD/Hint") != null)
	print("MENU_HUD_OK menu=1 new_game=1 hud=1")
	quit(0)
