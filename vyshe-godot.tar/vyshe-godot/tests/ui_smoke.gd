extends SceneTree
func _init() -> void:
	for path: String in ["res://scenes/ui/menu.tscn", "res://scenes/ui/pause.tscn", "res://scenes/ui/settings.tscn", "res://scenes/ui/memory_card.tscn", "res://scenes/ui/safeboot.tscn"]:
		var scene: PackedScene = load(path)
		assert(scene != null)
		var node: Node = scene.instantiate()
		assert(node != null)
	print("UI_SMOKE_OK screens=5")
	quit(0)
