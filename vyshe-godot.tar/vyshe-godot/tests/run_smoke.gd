extends SceneTree
const Generator = preload("res://src/world/strata_generator.gd")
const Validator = preload("res://src/world/level_validator.gd")
func _init() -> void:
	var a: Array[Dictionary] = Generator.build(12345, 12)
	var b: Array[Dictionary] = Generator.build(12345, 12)
	assert(a == b)
	assert(Validator.validate(a).is_empty())
	print("SMOKE_OK sections=%d" % a.size())
	quit(0)
