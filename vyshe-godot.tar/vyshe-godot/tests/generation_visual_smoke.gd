extends SceneTree

func _init() -> void:
	var scene: PackedScene = load("res://scenes/levels/section_runtime.tscn")
	var section: Node = scene.instantiate()
	root.add_child(section)
	section.build({"seed": 7771777, "origin": -300.0, "height": 8.0, "exit": -292.0, "index": 0, "zone_id": "bottom"})
	await process_frame
	assert(section.get_child_count() >= 20)
	assert(section.route_points.size() >= 4)
	assert(section.hatch != null)
	print("GENERATION_VISUAL_OK nodes=%d route=%d hatch=1" % [section.get_child_count(), section.route_points.size()])
	quit(0)
