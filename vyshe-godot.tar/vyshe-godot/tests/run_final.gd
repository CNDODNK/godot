extends SceneTree

func _init() -> void:
	var checks: Array[String] = [
				"res://scenes/game/render_polygon.tscn",
		"res://scenes/player/player.tscn",
		"res://scenes/ui/menu.tscn",
		"res://scenes/ui/pause.tscn",
		"res://scenes/ui/settings.tscn",
		"res://scenes/ui/memory_card.tscn",
		"res://scenes/ui/safeboot.tscn",
		"res://shaders/ps1_surface.gdshader",
		"res://shaders/ps1_post.gdshader",
		"res://shaders/water.gdshader"
	]
	for path: String in checks:
		if not ResourceLoader.exists(path): print("MISSING " + path); quit(1)
	print("FINAL_ASSET_CHECK_OK files=%d" % checks.size())
	quit(0)
