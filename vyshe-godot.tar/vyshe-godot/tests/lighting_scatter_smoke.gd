extends SceneTree
func _init() -> void:
	var scene: PackedScene = load("res://scenes/levels/section_runtime.tscn")
	var a: Node = scene.instantiate(); root.add_child(a)
	a.build({"seed": 1234, "origin": -300.0, "height": 8.0, "exit": -292.0, "index": 0, "zone_id": "bottom"})
	await process_frame
	assert(a.light_count >= 4)
	assert(a.scatter_count >= 5)
	var b: Node = scene.instantiate(); root.add_child(b)
	b.build({"seed": 1234, "origin": -300.0, "height": 8.0, "exit": -292.0, "index": 0, "zone_id": "bottom"})
	assert(b.light_count == a.light_count and b.scatter_count == a.scatter_count)
	print("LIGHT_SCATTER_OK lights=%d scatter=%d deterministic=1" % [a.light_count, a.scatter_count])
	quit(0)
