extends SceneTree
const World = preload("res://src/world/world_director_runtime.gd")
func _init() -> void:
	var world: VysheWorldRuntime = World.new()
	root.add_child(world)
	assert(world.start(99199))
	assert(world.loaded.size() == 4)
	world.active_index = 8
	world._update_stream()
	assert(world.loaded.has(8))
	assert(world.loaded.size() <= 6)
	print("WORLD_STREAM_OK loaded=%d sections=%d" % [world.loaded.size(), world.sections.size()])
	quit(0)
