extends SceneTree
func _init() -> void:
	var scene: PackedScene = load("res://scenes/game/game.tscn")
	assert(scene != null)
	var game: Node = scene.instantiate()
	root.add_child(game)
	await process_frame
	assert(game.get_node("Player") != null)
	assert(game.get_node("HUD") != null)
	assert(game.get_node("World").sections.size() == 32)
	print("GAME_SCENE_SMOKE_OK player=1 hud=1 sections=32")
	quit(0)
