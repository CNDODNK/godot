extends SceneTree

func _init() -> void:
	var scene: PackedScene = load("res://scenes/game/game.tscn")
	var game: Node = scene.instantiate()
	root.add_child(game)
	await process_frame
	var player: Node3D = game.get_node("Player")
	assert(player.global_position.y < -298.0)
	assert(absf(game.get_node("Ground/Shape").position.y + 300.2) < 0.01)
	assert(game.get_node("World").sections.size() == 32)
	assert(game.backdrop.cave_walls.visible)
	assert(game.backdrop.cave_lights.size() == 4)
	print("GAME_START_OK altitude=%.1f sections=32" % player.global_position.y)
	quit(0)
