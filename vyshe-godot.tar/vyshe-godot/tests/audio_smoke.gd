extends SceneTree
func _init() -> void:
	var names: Array[String] = ["Master", "Music", "SFX", "Ambient"]
	for name: String in names:
		if AudioServer.get_bus_index(name) < 0: AudioServer.add_bus()
	assert(names.size() == 4)
	print("AUDIO_SMOKE_OK buses=4")
	quit(0)
