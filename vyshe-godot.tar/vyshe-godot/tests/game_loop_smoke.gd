extends SceneTree
func _init() -> void:
	var scene: PackedScene = load("res://scenes/game/game.tscn")
	var game: Node = scene.instantiate()
	root.add_child(game)
	await process_frame
	var controller: Node = game
	assert(controller.player != null)
	assert(controller.world.sections.size() == 32)
	assert(controller.checkpoint_height <= -299.0)
	assert(controller.audio != null)
	assert(controller.backdrop != null)
	assert(controller.audio.players.size() == 5)
	assert(controller.backdrop.stars != null)
	assert(controller.backdrop.cave_walls != null)
	assert(controller.backdrop.cave_lights.size() == 4)
	assert(controller.ps1_overlay != null)
	assert(controller.ps1_overlay.material != null)
	controller.player.global_position.y = controller.checkpoint_height - 13.0
	await process_frame
	assert(controller.player.global_position.y >= controller.checkpoint_height - 0.1)
	print("GAME_LOOP_OK respawn=1 save_service=1 holds=1")
	quit(0)
