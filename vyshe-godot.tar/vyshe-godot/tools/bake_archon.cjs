// Экспорт только чистых рецептов из приложенного HTML. Браузер и Three.js не нужны.
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'reference/FINALHTMLVYSHE.html'), 'utf8');
function between(start, end, from = 0) {
  const a = source.indexOf(start, from);
  const b = source.indexOf(end, a + start.length);
  if (a < 0 || b < 0) throw new Error(`Source block missing: ${start}`);
  return source.slice(a, b);
}
const geometry = between('const ARCHON = (function(){', '\nfunction pgGenerateObject');
const additions = between('const NEW = {', '/* кеш порядка построек');
const extraThemes = between('ARCHON.THEME.ice   =', 'guard("profiles"');
const math = between('const clamp = (v,a,b)', 'const storage =');
const build = new Function(`${math}\n${geometry.replace('return { generate, CATALOG, THEME };', 'return { generate, CATALOG, THEME, construct };')}\n${additions}\n${extraThemes}\nreturn {ARCHON, mulberry32};`);
const { ARCHON, mulberry32 } = build();
const result = {};
for (const [theme, recipes] of Object.entries(ARCHON.CATALOG)) {
  result[theme] = recipes.map((entry, index) => {
    const built = ARCHON.construct(entry, ARCHON.THEME[theme], 7.5, mulberry32(777 + index));
    const parts = built.B.parts.filter(p => !['hold', 'anchor', 'bar'].includes(p.type)).map(p => [
      p.type, ...[p.x, p.y, p.z, p.w, p.h, p.d, p.rx, p.ry, p.rz].map(n => Math.round(n * 1000) / 1000), p.material, p.solid
    ]);
    if (parts.length < 4 || parts.some(p => p.slice(1, 10).some(x => !Number.isFinite(x)))) throw new Error(entry.id);
    return [entry.id, entry.name, parts];
  });
}
fs.writeFileSync(path.join(root, 'data/archon_catalog.json'), JSON.stringify(result));
console.log(`${Object.keys(result).length} themes, ${Object.values(result).flat().length} recipes`);
