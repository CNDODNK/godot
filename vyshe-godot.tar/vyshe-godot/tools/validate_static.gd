extends SceneTree
## Статический валидатор фазы 1 без запуска игрового рантайма.

func _init() -> void:
	var required: Array[String] = ["project.godot", "reference/FINALHTMLVYSHE.html", "docs/SPEC_FROM_HTML.md", "autoload/event_bus.gd", "autoload/game_state.gd"]
	var missing: Array[String] = []
	for path: String in required:
		if not FileAccess.file_exists("res://" + path): missing.append(path)
	if missing.is_empty(): print("STATIC_OK required_files=%d" % required.size())
	else:
		printerr("STATIC_FAIL missing=" + ",".join(missing))
		quit(1)
	quit(0)
