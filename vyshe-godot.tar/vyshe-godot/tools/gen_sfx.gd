extends SceneTree
func _init() -> void:
	var dir: DirAccess = DirAccess.open("res://assets/audio")
	if dir == null: quit(1); return
	var readme: FileAccess = FileAccess.open("res://assets/audio/README.md", FileAccess.WRITE)
	readme.store_string("Процедурные SFX создаются AudioStreamGenerator-узлами AudioDirector.\n")
	readme.close(); print("SFX_GENERATOR_OK"); quit(0)
